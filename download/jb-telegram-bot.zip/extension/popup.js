/**
 * JB Shopee Scraper — Popup Script v2 (SIMPLE)
 *
 * Cara pakai:
 * 1. Buka Shopee, browsing produk seperti biasa
 * 2. Klik extension → "Ambil Semua Produk di Halaman Ini"
 *    atau "Ambil 1 Produk" kalau di halaman detail
 * 3. Buka halaman lain, klik lagi → data nyimpel
 * 4. Kalau udah cukup, klik "Copy Semua ke CSV"
 * 5. Buka JB admin → Bulk Upload → paste di CSV → upload!
 *
 * GAK ada server. GAK ada bot. GAK ada database.
 * Murni copy-paste CSV aja.
 */

// CSV headers sesuai template JB
const CSV_HEADERS = 'title,url,image,price,originalPrice,discountPercent,rating,reviewCount,soldCount,location,category,marketplace,affiliateUrl,notes';

// Produk yang udah dikumpul (simpan di localStorage biar gak hilang)
let collected = [];

// Load dari localStorage
try {
  const saved = localStorage.getItem('jb_collected');
  if (saved) collected = JSON.parse(saved);
} catch {}

function saveCollected() {
  localStorage.setItem('jb_collected', JSON.stringify(collected));
  updateUI();
}

function updateUI() {
  const countBadge = document.getElementById('countBadge');
  const collectedList = document.getElementById('collectedList');
  const copyCsvBtn = document.getElementById('copyCsvBtn');

  countBadge.textContent = collected.length;

  if (collected.length === 0) {
    collectedList.innerHTML = '<div style="color:#666">Belum ada produk</div>';
    copyCsvBtn.disabled = true;
  } else {
    collectedList.innerHTML = collected.map((p, i) =>
      `<div>${i + 1}. ${escapeHtml(p.title.substring(0, 45))}${p.title.length > 45 ? '...' : ''}</div>`
    ).join('');
    copyCsvBtn.disabled = false;
  }
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Escape CSV field (handle koma, kutip, newline)
function csvField(val) {
  if (val == null || val === '') return '';
  const str = String(val);
  // Kalau ada koma, kutip, atau newline → bungkus kutip dua
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return '"' + str.replace(/"/g, '""') + '"';
  }
  return str;
}

function buildCSV() {
  const lines = [CSV_HEADERS];
  for (const p of collected) {
    lines.push([
      csvField(p.title),
      csvField(p.url),
      csvField(p.image),
      csvField(p.price),
      csvField(p.originalPrice),
      csvField(p.discountPercent),
      csvField(p.rating),
      csvField(p.reviewCount),
      csvField(p.soldCount),
      csvField(p.location),
      csvField(p.category),
      csvField(p.marketplace || 'shopee'),
      csvField(p.affiliateUrl),
      csvField(p.notes),
    ].join(','));
  }
  return lines.join('\n');
}

// ========== INIT ==========
document.addEventListener('DOMContentLoaded', async () => {
  const pageStatus = document.getElementById('pageStatus');
  const scrapePageBtn = document.getElementById('scrapePageBtn');
  const scrapeDetailBtn = document.getElementById('scrapeDetailBtn');
  const copyCsvBtn = document.getElementById('copyCsvBtn');
  const clearBtn = document.getElementById('clearBtn');
  const categorySelect = document.getElementById('categorySelect');

  let currentTab = null;
  let isShopee = false;
  let isDetail = false;

  // Cek halaman aktif
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    currentTab = tab;
    if (tab.url && tab.url.includes('shopee.co.id')) {
      isShopee = true;
      isDetail = !!tab.url.match(/-i\.\d+\.\d+/);
      if (isDetail) {
        pageStatus.textContent = '📄 Halaman produk detail Shopee';
        pageStatus.className = 'page-status ok';
      } else {
        pageStatus.textContent = '🔍 Halaman Shopee — siap scrape!';
        pageStatus.className = 'page-status ok';
      }
    }
  } catch {}

  scrapePageBtn.disabled = !isShopee;
  scrapeDetailBtn.disabled = !(isShopee && isDetail);

  // ====== AMBIL SEMUA PRODUK DI HALAMAN ======
  scrapePageBtn.addEventListener('click', async () => {
    scrapePageBtn.disabled = true;
    scrapePageBtn.textContent = '⏳ Membaca...';

    const category = categorySelect.value;

    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: currentTab.id },
        func: scrapeSearchPage,
        args: [category],
      });

      if (results?.[0]?.result) {
        const products = results[0].result;
        const before = collected.length;

        // Tambah yang belum ada (duplikat berdasarkan URL)
        const existingUrls = new Set(collected.map(p => p.url));
        let newCount = 0;
        for (const p of products) {
          if (!existingUrls.has(p.url)) {
            collected.push(p);
            existingUrls.add(p.url);
            newCount++;
          }
        }

        saveCollected();
        scrapePageBtn.textContent = `✅ +${newCount} baru (total ${collected.length})`;
        setTimeout(() => {
          scrapePageBtn.textContent = '📦 Ambil Semua Produk di Halaman Ini';
          scrapePageBtn.disabled = false;
        }, 2000);
      } else {
        scrapePageBtn.textContent = '❌ Gak bisa baca halaman';
        setTimeout(() => {
          scrapePageBtn.textContent = '📦 Ambil Semua Produk di Halaman Ini';
          scrapePageBtn.disabled = false;
        }, 2000);
      }
    } catch (err) {
      scrapePageBtn.textContent = '❌ Error: ' + err.message;
      setTimeout(() => {
        scrapePageBtn.textContent = '📦 Ambil Semua Produk di Halaman Ini';
        scrapePageBtn.disabled = false;
      }, 2000);
    }
  });

  // ====== AMBIL 1 PRODUK (DETAIL) ======
  scrapeDetailBtn.addEventListener('click', async () => {
    scrapeDetailBtn.disabled = true;
    scrapeDetailBtn.textContent = '⏳ Membaca...';

    const category = categorySelect.value;

    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: currentTab.id },
        func: scrapeProductDetail,
        args: [category],
      });

      if (results?.[0]?.result) {
        const product = results[0].result;
        const existingUrls = new Set(collected.map(p => p.url));

        if (existingUrls.has(product.url)) {
          scrapeDetailBtn.textContent = '⚠️ Produk ini udah ada!';
        } else {
          collected.push(product);
          saveCollected();
          scrapeDetailBtn.textContent = `✅ Ditambah! (total ${collected.length})`;
        }

        setTimeout(() => {
          scrapeDetailBtn.textContent = '🔍 Ambil 1 Produk (Detail)';
          scrapeDetailBtn.disabled = false;
        }, 2000);
      } else {
        scrapeDetailBtn.textContent = '❌ Gak bisa baca produk';
        setTimeout(() => {
          scrapeDetailBtn.textContent = '🔍 Ambil 1 Produk (Detail)';
          scrapeDetailBtn.disabled = false;
        }, 2000);
      }
    } catch (err) {
      scrapeDetailBtn.textContent = '❌ Error';
      setTimeout(() => {
        scrapeDetailBtn.textContent = '🔍 Ambil 1 Produk (Detail)';
        scrapeDetailBtn.disabled = false;
      }, 2000);
    }
  });

  // ====== COPY CSV ======
  copyCsvBtn.addEventListener('click', () => {
    const csv = buildCSV();
    navigator.clipboard.writeText(csv).then(() => {
      copyCsvBtn.textContent = `✅ CSV dicopy! (${collected.length} produk)`;
      setTimeout(() => {
        copyCsvBtn.textContent = '📋 Copy Semua ke CSV (Paste ke JB)';
      }, 3000);
    }).catch(() => {
      // Fallback: tampilkan di textarea
      const ta = document.createElement('textarea');
      ta.value = csv;
      ta.style.cssText = 'width:100%;height:150px;font-size:10px;background:#0f0f23;color:#eee;border:1px solid #333;border-radius:4px;padding:6px;margin-top:6px;';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      copyCsvBtn.textContent = `✅ Dicopy! (${collected.length} produk)`;
      setTimeout(() => {
        ta.remove();
        copyCsvBtn.textContent = '📋 Copy Semua ke CSV (Paste ke JB)';
      }, 3000);
    });
  });

  // ====== HAPUS SEMUA ======
  clearBtn.addEventListener('click', () => {
    if (collected.length === 0) return;
    if (confirm(`Hapus ${collected.length} produk yang udah dikumpul?`)) {
      collected = [];
      saveCollected();
    }
  });

  // Initial UI update
  updateUI();
});


// ================================================================
//  SCRAPING FUNCTIONS — jalan DI DALAM halaman Shopee
// ================================================================

function scrapeSearchPage(category) {
  const products = [];
  const url = window.location.href;

  const links = document.querySelectorAll('a[href*="-i."]');

  for (const link of links) {
    try {
      const product = { category, marketplace: 'shopee' };
      const text = link.innerText || '';
      const href = link.getAttribute('href') || '';

      // URL
      product.url = href.startsWith('/') ? 'https://shopee.co.id' + href : href;

      // shopId & itemId
      const idMatch = href.match(/-i\.(\d+)\.(\d+)/);
      if (!idMatch) continue;

      // Judul — baris pertama yang panjang
      const lines = text.split('\n').map(l => l.trim()).filter(l => l.length > 5);
      if (lines.length > 0) product.title = lines[0];
      if (!product.title || product.title.length < 3) continue;

      // Harga
      const priceMatch = text.match(/Rp([\d.]+)/);
      if (priceMatch) product.price = parseInt(priceMatch[1].replace(/\./g, ''), 10);

      // Kalau ada 2 harga (diskon)
      const allPrices = [...text.matchAll(/Rp([\d.]+)/g)];
      if (allPrices.length > 1) {
        const firstPrice = parseInt(allPrices[0][1].replace(/\./g, ''), 10);
        const secondPrice = parseInt(allPrices[1][1].replace(/\./g, ''), 10);
        if (secondPrice > firstPrice) {
          product.originalPrice = secondPrice;
          if (product.originalPrice > 0 && product.price > 0) {
            product.discountPercent = Math.round((1 - product.price / product.originalPrice) * 100);
          }
        }
      }

      // Terjual
      const soldMatch = text.match(/([\d.]+)\s*terjual/i);
      if (soldMatch) {
        product.soldCount = parseInt(soldMatch[1].replace(/\./g, ''), 10);
      } else {
        const rbMatch = text.match(/([\d,]+)\s*rb\s*terjual/i);
        if (rbMatch) product.soldCount = Math.round(parseFloat(rbMatch[1].replace(',', '.')) * 1000);
      }

      // Rating
      const ratingMatch = text.match(/(\d+[,.]\d+)/);
      if (ratingMatch) product.rating = parseFloat(ratingMatch[1].replace(',', '.'));

      // Gambar
      const img = link.querySelector('img');
      if (img) {
        const src = img.getAttribute('src') || img.getAttribute('data-src') || '';
        if (src && !src.startsWith('data:')) product.image = src;
      }

      if (product.title && product.price) {
        products.push(product);
      }
    } catch {}
  }

  // Hilangkan duplikat
  const seen = new Set();
  return products.filter(p => {
    const key = p.url;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function scrapeProductDetail(category) {
  const bodyText = document.body.innerText;
  const url = window.location.href;
  const product = { category, marketplace: 'shopee', url };

  // Judul
  const titleSelectors = ['h1', '[class*="qaNIZv"]', '[class*="WBVL_7"]', '[class*="_44qnta"]', 'span[class*="title"]'];
  for (const sel of titleSelectors) {
    const el = document.querySelector(sel);
    if (el && el.textContent.trim().length > 3) {
      product.title = el.textContent.trim();
      break;
    }
  }

  // Harga
  const priceMatch = bodyText.match(/Rp([\d.]+)/);
  if (priceMatch) product.price = parseInt(priceMatch[1].replace(/\./g, ''), 10);

  // Harga asli (diskon)
  const allPrices = [...bodyText.matchAll(/Rp([\d.]+)/g)];
  if (allPrices.length > 1) {
    const secondPrice = parseInt(allPrices[1][1].replace(/\./g, ''), 10);
    if (secondPrice > (product.price || 0)) {
      product.originalPrice = secondPrice;
      if (product.originalPrice > 0 && product.price > 0) {
        product.discountPercent = Math.round((1 - product.price / product.originalPrice) * 100);
      }
    }
  }

  // Terjual
  const soldMatch = bodyText.match(/([\d.]+)\s*terjual/i);
  if (soldMatch) {
    product.soldCount = parseInt(soldMatch[1].replace(/\./g, ''), 10);
  } else {
    const rbMatch = bodyText.match(/([\d,]+)\s*rb\s*terjual/i);
    if (rbMatch) product.soldCount = Math.round(parseFloat(rbMatch[1].replace(',', '.')) * 1000);
  }

  // Rating
  const ratingMatch = bodyText.match(/(\d+[,.]\d+)/);
  if (ratingMatch) product.rating = parseFloat(ratingMatch[1].replace(',', '.'));

  // Lokasi
  const locMatch = bodyText.match(/Dikirim dari\s*([^\n,]+)/i);
  if (locMatch) product.location = locMatch[1].trim();

  // Gambar
  const imgSelectors = ['img[class*="product"]', 'img[src*="susercontent"]', 'img[src*="down-id"]'];
  for (const sel of imgSelectors) {
    const el = document.querySelector(sel);
    if (el) {
      product.image = el.getAttribute('src') || null;
      break;
    }
  }

  return product;
}
