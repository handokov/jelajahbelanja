# JB Scraper v12 — Chrome Extension

## Yang Baru di v12

### 1. Auto-scroll untuk load lebih banyak produk
Shopee lazy-load produk saat scroll. v11 cuma bisa ambil 10-15 produk yang ke-load.
v12 otomatis scroll ke bottom 8x (1.2s tiap scroll) untuk load 30+ produk.

### 2. Fetch Shopee API per produk → data LENGKAP
v11: bulk scrape cuma dapat title + link (image, rating, review, sold KOSONG).
v12: setelah dapat URL list, call Shopee API per produk untuk dapat:
- ✅ Image URL (akurat dari API)
- ✅ Price + originalPrice + discountPercent
- ✅ Rating (bintang)
- ✅ reviewCount (jumlah rating/review)
- ✅ soldCount (jumlah terjual)
- ✅ Location (lokasi seller)
- ✅ Title (nama produk lengkap)

### 3. Improved reviewCount & soldCount extraction
v11: reviewCount sering kosong (regex tidak match DOM Shopee yang berubah).
v12: extract langsung dari API response field `item_rating.rating_count` dan
`historical_sold`. Handle 3 format response (array, number, fallback).

### 4. Fallback mode
Kalau API gagal total (cth: Shopee block sementara), v12 otomatis fallback
ke DOM-only scrape (v11 mode) supaya tetap dapat data walau terbatas.

## Cara Pakai

### Install
1. Buka Edge/Chrome
2. Ketik di address bar: `edge://extensions` (atau `chrome://extensions`)
3. Aktifkan "Developer mode" (toggle kanan atas)
4. Klik "Load unpacked"
5. Pilih folder `scraper-v12`
6. Icon JB muncul di toolbar!

### Scrape (Mode Bulk — 30+ produk)
1. Buka `shopee.co.id`
2. Cari produk: "kaos kaki" / "tumbler" / "dress anak" / dll
3. **Sort: Terlaris** (untuk dapat produk best seller)
4. Klik icon JB Scraper di toolbar
5. Pilih kategori
6. Klik **"📦 Ambil Semua Produk di Halaman Ini"**
7. Tunggu ~30-40 detik (auto-scroll + fetch API per produk)
8. Tombol akan show: `✅ +30 baru | ⭐30 📦30 💬30 🖼30/30`
   - ⭐30 = 30 produk dapat rating
   - 📦30 = 30 produk dapat sold count
   - 💬30 = 30 produk dapat review count
   - 🖼30 = 30 produk dapat image URL
9. Buka halaman search lain (page 2, 3, dll) → klik lagi untuk tambah produk
10. Kalau udah cukup, klik **"💾 Download File CSV (Format JB)"**

### Scrape (Mode Single — 1 produk detail)
1. Buka halaman detail produk Shopee (cth: `shopee.co.id/produk-i.shopId.itemId`)
2. Klik icon JB Scraper
3. Klik **"🔍 Ambil 1 Produk (Halaman Detail)"**
4. Tunggu 2-3 detik (fetch API)
5. Tombol show: `✅ Ditambah! ⭐4.8 📦1200 (total 5)`

### Upload ke JB Admin
1. Login admin JB → tab **Upload Massal** → mode **JB Upload**
2. Upload file CSV yang didownload
3. Klik **"🪄 Auto-generate AT Custom Links"** (auto bikin atid.me/go/xxx)
4. Klik **"Upload Produk"**

## Estimasi Waktu

| Mode | Jumlah Produk | Estimasi Waktu |
|------|--------------|----------------|
| Bulk (v12) | 30 produk | ~30-40 detik (auto-scroll 10s + API fetch 30x0.7s) |
| Single (v12) | 1 produk | ~2-3 detik |
| Bulk (v11 lama) | 10-15 produk | ~3 detik (tapi data tidak lengkap) |

v12 lebih lambat tapi data LENGKAP. Trade-off worth it.

## Troubleshooting

### "❌ Gak bisa baca"
- Pastikan di halaman search Shopee (URL: `shopee.co.id/search?...`)
- Scroll manual dulu sebelum klik tombol (tambahan load)
- Coba refresh halaman, lalu klik scraper lagi

### "⚠️ +X (DOM mode — data terbatas)"
- API Shopee sedang block sementara (terlalu banyak request)
- Tunggu 5-10 menit, lalu coba lagi
- DOM mode tetap dapat title + price, tapi rating/review/sold mungkin kosong

### reviewCount/soldCount masih kosong untuk beberapa produk
- Mungkin produk tersebut baru (belum ada review/penjualan)
- Atau produk sudah dihapus seller
- Cek manual di Shopee untuk verify

### Cuma dapat 10-15 produk (bukan 30+)
- Auto-scroll mungkin tidak cukup — scroll manual ke bottom dulu
- Atau Shopee cuma punya sedikit produk untuk keyword tersebut
- Coba keyword lain yang lebih general
