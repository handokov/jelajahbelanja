# JB Scraper (All Marketplace) v3.0

Scrape produk dari **8 marketplace** (TikTok Shop, Tokopedia, Shopee, Blibli, Lazada, Bukalapak, Zalora, Sociolla) → koleksi → **Download CSV** atau **Upload langsung ke JB**.

## Yang Baru di v3.0

### 1. Mode 2: Paste Link Produk 🔗
Tidak perlu buka halaman produk satu-satu di tab. Cukup paste URL produk di textarea (bisa multiple, 1 per baris), scraper akan:
- Buka tab background (tidak ganggu tab aktif Anda)
- Tunggu page fully loaded
- Execute scraper
- Tutup tab background otomatis
- Ulangi untuk URL berikutnya

**Limit**: 20 URL per session (supaya tidak terlalu lama).

### 2. Download CSV 💾
Sebelumnya cuma bisa upload langsung ke JB. Sekarang ada 2 opsi output:
- **💾 Download CSV** — simpan ke file CSV → upload manual via JB admin Bulk Upload (bisa auto-generate AT Custom Links dulu)
- **📤 Upload Semua ke JB** — langsung upload ke DB JB (perlu Admin Secret)

CSV format sama dengan v12: `title,url,image,price,originalPrice,discountPercent,rating,reviewCount,soldCount,location,category,marketplace,affiliateUrl,notes`

## Cara Pakai

### Install
1. Download & extract zip ini
2. Buka `edge://extensions` (atau `chrome://extensions`)
3. Aktifkan **Developer mode** (toggle kanan atas)
4. **Remove** versi lama (v2.2.0) kalau ada
5. **Load unpacked** → pilih folder hasil extract
6. Icon JB muncul di toolbar

### Mode 1 — Halaman Aktif (cara lama, tetap ada)
1. Buka halaman produk di marketplace (Shopee/Tokopedia/TikTok/dll)
2. Klik icon JB Scraper
3. Klik **"➕ Tambah ke Koleksi (Halaman Aktif)"**
4. Produk masuk ke koleksi

### Mode 2 — Paste Link (v3.0 baru)
1. Klik icon JB Scraper
2. Scroll ke section **"🔗 Paste Link Produk"**
3. Paste URL produk di textarea (1 per baris):
   ```
   https://shopee.co.id/produk-i.xxx.xxx
   https://www.tokopedia.com/xxx/xxx
   https://www.tiktok.com/@xxx/product/xxx
   ```
4. Klik **"🔗 Scrape dari Link"**
5. Tunggu ~15 detik per URL (buka tab, load, scrape, tutup)
6. Status: `✅ 5 produk berhasil ditambahkan ke koleksi!`

### Output
Setelah koleksi terisi, pilih salah satu:
- **💾 Download CSV** → file CSV tersimpan → upload via JB admin Bulk Upload
- **📤 Upload Semua ke JB** → langsung upload (perlu isi Admin Secret di Config)
- **🗑️ Clear** → reset koleksi

## Workflow yang Disarankan

### Workflow A: Bulk Upload + Auto-generate AT Links (RECOMMENDED)
1. Scrape 10-20 produk (Mode 1 atau Mode 2)
2. Klik **💾 Download CSV**
3. Login admin JB → Upload Massal → JB Upload
4. Upload file CSV
5. Klik **🪄 Auto-generate AT Custom Links** (auto bikin atid.me/go/xxx)
6. Klik **Upload Produk**
7. Selesai!

### Workflow B: Direct Upload (cara lama)
1. Isi Admin Secret di Config section
2. Scrape produk
3. Klik **📤 Upload Semua ke JB**
4. Selesai!

**Workflow A lebih baik** karena:
- Bisa auto-generate AT Custom Links (tracking per produk di AT dashboard)
- Bisa review data sebelum upload
- Tidak perlu isi Admin Secret di extension (lebih aman)

## Troubleshooting

### Mode 2: "gagal scrape (page belum loaded?)"
- Marketplace mungkin lambat load → coba kurangi jumlah URL per session
- Beberapa marketplace (TikTok) butuh login → scrape di Mode 1 setelah login
- Coba refresh halaman marketplace manual dulu, lalu paste link lagi

### Mode 2: "marketplace tidak dikenali"
- Pastikan URL lengkap dengan `https://`
- Cek URL valid: `shopee.co.id`, `tokopedia.com`, `tiktok.com`, `blibli.com`, `lazada.co.id`, `bukalapak.com`, `zalora.co.id`, `sociolla.com`

### Download CSV: file tidak muncul
- Cek folder Downloads browser Anda
- Nama file: `jb-scrape-YYYY-MM-DD-Nproduk.csv`
- Kalau browser block download, allow popup/download untuk extension

### Upload Semua gagal
- Pastikan Admin Secret benar (cek di JB admin login)
- Pastikan API Base URL benar (`https://jelajahbelanja.com`)
- Cek koneksi internet

## Marketplace yang Didukung

| Marketplace | URL Pattern | Scraper |
|-------------|-------------|---------|
| Shopee | shopee.co.id | ✅ |
| Tokopedia | tokopedia.com | ✅ |
| TikTok Shop | tiktok.com, shop.tiktok.com | ✅ |
| Blibli | blibli.com | ✅ |
| Lazada | lazada.co.id | ✅ |
| Bukalapak | bukalapak.com | ✅ |
| Zalora | zalora.co.id | ✅ |
| Sociolla | sociolla.com | ✅ |

## Version History
- **v3.0.0** (current): Tambah Mode 2 (Paste Link) + Download CSV option
- v2.2.0: 8 marketplace support, direct upload
- v1.0.0: Shopee only, copy CSV manual
