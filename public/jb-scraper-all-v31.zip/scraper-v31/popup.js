/**
 * JB Scraper v1.2 — Koleksi multi-produk + batch upload
 *
 * Fitur:
 * - Scrape produk → masuk ke koleksi (localStorage)
 * - Koleksi banyak produk (10, 20, 30, dst)
 * - Upload semua sekaligus (batch)
 * - Auto-detect marketplace (TikTok / Tokopedia)
 * - Skip duplikat (URL sama)
 * - Remove per produk
 */

// State
let config = {
  adminSecret: '',
  apiBase: 'https://jelajahbelanja.com'
};

// Load config
chrome.storage.local.get(['jbConfig', 'jbCollection'], (result) => {
  if (result.jbConfig) {
    config = { ...config, ...result.jbConfig };
    document.getElementById('adminSecret').value = config.adminSecret || '';
    document.getElementById('apiBase').value = config.apiBase || 'https://jelajahbelanja.com';
  }
  renderCollection();
});

// Save config
document.getElementById('saveConfig').addEventListener('click', () => {
  config.adminSecret = document.getElementById('adminSecret').value.trim();
  config.apiBase = document.getElementById('apiBase').value.trim().replace(/\/$/, '');
  chrome.storage.local.set({ jbConfig: config }, () => {
    showStatus('✅ Config disimpan!', 'success');
    setTimeout(() => hideStatus(), 2000);
  });
});

// Detect marketplace dari URL
function detectMarketplace(url) {
  const lower = url.toLowerCase();
  if (lower.includes('tiktok.com') || lower.includes('shop.tiktok.com')) return 'tiktok';
  if (lower.includes('tokopedia.com') || lower.includes('ta.tokopedia.com') ||
      lower.includes('tokopedia.link') || lower.includes('toko.link') ||
      lower.includes('shop-id.tokopedia.com')) return 'tokopedia';
  if (lower.includes('shopee.co.id') || lower.includes('shopee.com') || lower.includes('shope.ee') || lower.includes('shp.ee')) return 'shopee';
  if (lower.includes('blibli.com')) return 'blibli';
  if (lower.includes('lazada.co.id')) return 'lazada';
  if (lower.includes('bukalapak.com')) return 'bukalapak';
  if (lower.includes('zalora.co.id')) return 'zalora';
  if (lower.includes('sociolla.com')) return 'sociolla';
  return null;
}

// === KOLEKSI MANAGEMENT ===

function getCollection() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['jbCollection'], (result) => {
      resolve(result.jbCollection || []);
    });
  });
}

function saveCollection(collection) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ jbCollection: collection }, resolve);
  });
}

async function addToCollection(product) {
  const collection = await getCollection();

  // Cek duplikat by URL
  const exists = collection.find(p => p.url === product.url);
  if (exists) {
    showStatus('⚠️ Produk sudah ada di koleksi (URL sama), di-skip.', 'error');
    return false;
  }

  collection.push(product);
  await saveCollection(collection);
  renderCollection();
  return true;
}

async function removeFromCollection(index) {
  const collection = await getCollection();
  collection.splice(index, 1);
  await saveCollection(collection);
  renderCollection();
}

async function clearCollection() {
  await saveCollection([]);
  renderCollection();
}

async function renderCollection() {
  const collection = await getCollection();
  const listEl = document.getElementById('productList');
  const countBadge = document.getElementById('countBadge');
  const uploadAllBtn = document.getElementById('uploadAllBtn');
  const clearAllBtn = document.getElementById('clearAllBtn');
  const downloadCsvBtn = document.getElementById('downloadCsvBtn');

  if (collection.length === 0) {
    listEl.innerHTML = '<div class="empty-list">Belum ada produk terkumpul.<br>Scrape beberapa produk dulu.</div>';
    countBadge.style.display = 'none';
    uploadAllBtn.disabled = true;
    clearAllBtn.disabled = true;
    if (downloadCsvBtn) downloadCsvBtn.disabled = true;
  } else {
    countBadge.style.display = 'inline-block';
    countBadge.textContent = collection.length;
    uploadAllBtn.disabled = false;
    clearAllBtn.disabled = false;
    if (downloadCsvBtn) downloadCsvBtn.disabled = false;

    listEl.innerHTML = collection.map((p, i) => `
      <div class="product-item" style="flex-direction:column;align-items:stretch;">
        <div style="display:flex;align-items:center;gap:8px;">
          <img src="${p.image || ''}" alt="" class="product-thumb" data-index="${i}">
          <div class="info" style="flex:1;">
            <div class="info-title">${escapeHtml(p.title.slice(0, 40))}${p.title.length > 40 ? '...' : ''}</div>
            <div class="info-price">${formatRupiah(p.price)}</div>
            <div class="info-mp">${p.marketplace}${p.affiliateUrl ? ' ✅' : ' ⚠️ no aff'}</div>
          </div>
          <div style="display:flex;flex-direction:column;gap:2px;">
            <button class="copy-img-btn" data-index="${i}" data-url="${escapeHtml(p.image || '')}" title="Copy Image URL" style="background:#f4f4f5;border:1px solid #e4e4e7;border-radius:4px;padding:3px 6px;font-size:9px;cursor:pointer;color:#71717a;">📋 Copy Img</button>
            <button class="remove" data-index="${i}" title="Hapus" style="background:none;border:none;color:#ef4444;cursor:pointer;font-size:14px;padding:0 4px;">✕</button>
          </div>
        </div>
        <input type="text" class="aff-input" data-index="${i}" placeholder="Paste affiliate URL di sini..." value="${p.affiliateUrl || ''}" style="width:100%;margin-top:4px;padding:4px 6px;font-size:10px;border:1px solid #e4e4e7;border-radius:4px;background:#f9fafb;">
        <input type="text" class="img-input" data-index="${i}" placeholder="Image URL (bisa diubah / paste Cloudinary URL)" value="${p.image || ''}" style="width:100%;margin-top:2px;padding:4px 6px;font-size:10px;border:1px solid #e4e4e7;border-radius:4px;background:#f9fafb;">
      </div>
    `).join('');

    // Fix CSP: pakai event listener, bukan inline onerror
    listEl.querySelectorAll('.product-thumb').forEach(img => {
      img.addEventListener('error', function() {
        this.style.background = '#f4f4f5';
        this.src = '';
        this.alt = 'no image';
      });
    });

    // Copy image URL handlers
    listEl.querySelectorAll('.copy-img-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const url = e.target.dataset.url;
        if (!url) return;
        try {
          await navigator.clipboard.writeText(url);
          e.target.textContent = '✅ Copied!';
          e.target.style.background = '#dcfce7';
          e.target.style.color = '#166534';
          setTimeout(() => {
            e.target.textContent = '📋 Copy Img';
            e.target.style.background = '#f4f4f5';
            e.target.style.color = '#71717a';
          }, 1500);
        } catch {
          // Fallback
          const tempInput = document.createElement('input');
          tempInput.value = url;
          document.body.appendChild(tempInput);
          tempInput.select();
          try { document.execCommand('copy'); } catch {}
          document.body.removeChild(tempInput);
          e.target.textContent = '✅ Copied!';
          setTimeout(() => { e.target.textContent = '📋 Copy Img'; }, 1500);
        }
      });
    });

    // Image URL input handlers (bisa diubah / paste Cloudinary URL)
    listEl.querySelectorAll('.img-input').forEach(input => {
      input.addEventListener('change', async (e) => {
        const idx = parseInt(e.target.dataset.index, 10);
        const url = e.target.value.trim();
        const coll = await getCollection();
        if (coll[idx]) {
          coll[idx].image = url;
          await saveCollection(coll);
          // Update thumbnail
          const thumb = e.target.parentElement.querySelector('.product-thumb');
          if (thumb) { thumb.src = url; thumb.style.display = url ? '' : 'none'; }
          // Update copy button data
          const copyBtn = e.target.parentElement.querySelector('.copy-img-btn');
          if (copyBtn) copyBtn.dataset.url = url;
        }
      });
    });

    // Affiliate URL input handlers
    listEl.querySelectorAll('.aff-input').forEach(input => {
      input.addEventListener('change', async (e) => {
        const idx = parseInt(e.target.dataset.index, 10);
        const url = e.target.value.trim();
        const coll = await getCollection();
        if (coll[idx]) {
          coll[idx].affiliateUrl = url || null;
          await saveCollection(coll);
          // Update indicator
          const mpEl = e.target.parentElement.querySelector('.info-mp');
          if (mpEl) mpEl.textContent = `${coll[idx].marketplace}${url ? ' ✅' : ' ⚠️ no aff'}`;
        }
      });
    });

    // Add remove handlers
    listEl.querySelectorAll('.remove').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const idx = parseInt(e.target.dataset.index, 10);
        removeFromCollection(idx);
      });
    });
  }
}

function escapeHtml(s) {
  const div = document.createElement('div');
  div.textContent = s;
  return div.innerHTML;
}

// === SCRAPE BUTTON ===

document.getElementById('scrapeBtn').addEventListener('click', async () => {
  showStatus('⏳ Scrapping...', 'loading');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const marketplace = detectMarketplace(tab.url);

    if (!marketplace) {
      showStatus('❌ Buka halaman produk di marketplace yang didukung (Shopee/Tokopedia/TikTok/Blibli/Lazada/Bukalapak/Zalora/Sociolla)!', 'error');
      return;
    }

    let scraperFunc;
    if (marketplace === 'tiktok') scraperFunc = scrapeTikTokProduct;
    else if (marketplace === 'tokopedia') scraperFunc = scrapeTokopediaProduct;
    else if (marketplace === 'shopee') scraperFunc = scrapeShopeeProduct;
    else if (marketplace === 'blibli') scraperFunc = scrapeBlibliProduct;
    else if (marketplace === 'lazada') scraperFunc = scrapeLazadaProduct;
    else if (marketplace === 'bukalapak') scraperFunc = scrapeBukalapakProduct;
    else if (marketplace === 'zalora') scraperFunc = scrapeZaloraProduct;
    else if (marketplace === 'sociolla') scraperFunc = scrapeSociollaProduct;
    else {
      showStatus(`❌ Marketplace ${marketplace} belum didukung.`, 'error');
      return;
    }

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: scraperFunc,
    });

    const product = results[0]?.result;

    if (!product || !product.title) {
      showStatus('❌ Gagal scrape. Pastikan di halaman produk tunggal.', 'error');
      return;
    }

    product.marketplace = marketplace;

    // Validate required fields — show which ones missing
    const missing = [];
    if (!product.title) missing.push('title');
    if (!product.image) missing.push('image');
    if (!product.price || product.price === 0) missing.push('price');
    if (!product.category) missing.push('category');
    if (!product.url) missing.push('url');

    if (missing.length > 0) {
      showStatus(`❌ Field kosong: ${missing.join(', ')}. Tunggu page fully loaded lalu coba lagi.`, 'error');
      return;
    }

    const added = await addToCollection(product);
    if (added) {
      showStatus(`✅ Ditambahkan! (${await getCollectionLength()} produk di koleksi)`, 'success');
    }
  } catch (err) {
    showStatus('❌ Error: ' + err.message, 'error');
  }
});

async function getCollectionLength() {
  const c = await getCollection();
  return c.length;
}

// ═══════════════════════════════════════════════════════════════════
// v3.1: MODE KLIK OVERLAY (aiprice-style) — klik tombol di card produk
// ═══════════════════════════════════════════════════════════════════
// User buka halaman search/kategori Shopee → klik "Aktifkan Mode Klik"
// → scraper inject tombol "➕ JB" ke tiap product card di halaman itu.
// User klik tombol → produk itu di-scrape + add to collection.

function showOverlayStatus(message, type) {
  const status = document.getElementById('overlayStatus');
  status.textContent = message;
  status.className = 'status ' + type;
}

// State: mode klik aktif atau tidak (disimpan supaya survive popup close)
let overlayModeActive = false;

document.getElementById('overlayModeBtn').addEventListener('click', async () => {
  const btn = document.getElementById('overlayModeBtn');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url) {
      showOverlayStatus('❌ Tidak bisa akses tab aktif.', 'error');
      return;
    }

    const marketplace = detectMarketplace(tab.url);
    if (!marketplace) {
      showOverlayStatus('❌ Buka halaman Shopee/Tokopedia/dll dulu.', 'error');
      return;
    }

    if (!overlayModeActive) {
      // AKTIFKAN mode klik
      // Inject content script + CSS ke halaman aktif
      await chrome.scripting.insertCSS({
        target: { tabId: tab.id },
        css: `
          .jb-overlay-btn {
            position: absolute;
            top: 6px;
            right: 6px;
            z-index: 9999;
            background: linear-gradient(135deg, #7c3aed, #a855f7);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 5px 10px;
            font-size: 11px;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(124, 58, 237, 0.4);
            transition: all 0.15s;
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
          }
          .jb-overlay-btn:hover {
            transform: scale(1.1);
            box-shadow: 0 4px 12px rgba(124, 58, 237, 0.6);
          }
          .jb-overlay-btn.jb-added {
            background: linear-gradient(135deg, #10b981, #059669);
            cursor: default;
          }
          .jb-overlay-btn.jb-loading {
            background: linear-gradient(135deg, #6b7280, #4b5563);
            cursor: wait;
          }
          .jb-overlay-btn.jb-error {
            background: linear-gradient(135deg, #ef4444, #dc2626);
          }
          .jb-toast {
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: #10b981;
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            z-index: 100000;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            animation: jbSlideUp 0.3s ease-out;
          }
          @keyframes jbSlideUp {
            from { transform: translate(-50%, 20px); opacity: 0; }
            to { transform: translate(-50%, 0); opacity: 1; }
          }
        `,
      });

      // Inject content script yang menambahkan tombol ke tiap product card
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: injectOverlayButtons,
        args: [marketplace],
      });

      overlayModeActive = true;
      btn.textContent = '🛑 Matikan Mode Klik';
      btn.style.background = 'linear-gradient(135deg, #ef4444, #dc2626)';
      showOverlayStatus('✅ Mode Klik AKTIF! Klik tombol "➕ JB" di produk yang mau di-scrape di halaman ini.', 'success');

      // Tutup popup supaya user bisa lihat halaman + klik tombol
      setTimeout(() => window.close(), 1500);
    } else {
      // MATIKAN mode klik — hapus tombol dari halaman
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: removeOverlayButtons,
      });

      overlayModeActive = false;
      btn.textContent = '🖱️ Aktifkan Mode Klik di Halaman';
      btn.style.background = 'linear-gradient(135deg, #7c3aed, #a855f7)';
      showOverlayStatus('🛑 Mode Klik dimatikan.', 'success');
    }
  } catch (err) {
    showOverlayStatus('❌ Error: ' + (err.message || 'unknown'), 'error');
  }
});

// Function yang di-inject ke halaman Shopee untuk tambah tombol overlay
// ke tiap product card. Pakai MutationObserver supaya tombol tetap muncul
// saat Shopee lazy-load produk baru.
function injectOverlayButtons(marketplace) {
  // Hapus dulu kalau sudah ada (supaya tidak double)
  if (document.getElementById('jb-overlay-style')) return;

  // Track URL yang sudah di-add (supaya tombol langsung hijau)
  const addedUrls = new Set();
  try {
    const stored = JSON.parse(sessionStorage.getItem('jb-added-urls') || '[]');
    stored.forEach(u => addedUrls.add(u));
  } catch {}

  // Selector product card per marketplace
  function getCardSelector(mp) {
    if (mp === 'shopee') return 'a[href*="-i."]';
    if (mp === 'tokopedia') return 'a[href*="/product/"]';
    if (mp === 'lazada') return 'a[href*="/products/"]';
    if (mp === 'blibli') return 'a[href*="/p/"]';
    if (mp === 'bukalapak') return 'a[href*="/product/"]';
    if (mp === 'tiktok') return 'a[href*="/product/"]';
    return 'a[href*="-i."]';
  }

  function extractProductData(card) {
    const href = card.getAttribute('href') || '';
    let url = href.startsWith('/') ? window.location.origin + href : href;
    url = url.split('?')[0]; // strip query params

    // Ambil title dari text card
    const text = card.innerText || '';
    const lines = text.split('\n').map(l => l.trim()).filter(l => l.length > 5);
    const title = lines[0] || '';

    // Ambil price
    let price = 0;
    const priceMatch = text.match(/Rp\s*([\d.]+)/i) || text.match(/(\d[\d.]*)/);
    if (priceMatch) {
      const num = parseInt(priceMatch[1].replace(/\./g, ''), 10);
      if (num > 100) price = num;
    }

    // Ambil image
    let image = '';
    const img = card.querySelector('img');
    if (img) {
      const src = img.getAttribute('src') || img.getAttribute('data-src') || '';
      if (src && !src.startsWith('data:') && src.includes('susercontent')) {
        image = src;
      } else if (src && src.startsWith('http')) {
        image = src;
      }
    }

    // Ambil sold count
    let soldCount = 0;
    const soldMatch = text.match(/([\d.,]+)\s*(?:rb|ribu)?\s*terjual/i);
    if (soldMatch) {
      const s = soldMatch[1].replace(',', '.');
      if (s.includes('rb') || text.toLowerCase().includes('rb terjual')) {
        soldCount = Math.round(parseFloat(s) * 1000);
      } else {
        soldCount = parseInt(s.replace(/\./g, ''), 10) || 0;
      }
    }

    // Ambil rating
    let rating = 0;
    const ratingMatch = text.match(/(\d+[.,]\d+)/);
    if (ratingMatch) {
      rating = parseFloat(ratingMatch[1].replace(',', '.'));
      if (rating > 5) rating = 0; // invalid
    }

    // Extract shopId & itemId dari URL Shopee
    let shopId = '', itemId = '';
    const idMatch = href.match(/-i\.(\d+)\.(\d+)/);
    if (idMatch) {
      shopId = idMatch[1];
      itemId = idMatch[2];
    }

    return { url, title, price, image, soldCount, rating, shopId, itemId };
  }

  function createOverlayButton(card, productData) {
    // Pastikan card punya position relative supaya button absolute positioning benar
    if (getComputedStyle(card).position === 'static') {
      card.style.position = 'relative';
    }

    const btn = document.createElement('button');
    btn.className = 'jb-overlay-btn';
    btn.textContent = '➕ JB';

    // Kalau sudah di-add, tampil hijau
    if (addedUrls.has(productData.url)) {
      btn.classList.add('jb-added');
      btn.textContent = '✓ Added';
    }

    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();

      if (btn.classList.contains('jb-added') || btn.classList.contains('jb-loading')) return;

      btn.classList.add('jb-loading');
      btn.textContent = '⏳ Scraping...';

      try {
        // Coba fetch Shopee API kalau ada shopId & itemId (Shopee only)
        let product = {
          marketplace: marketplace,
          url: productData.url,
          title: productData.title,
          price: productData.price,
          image: productData.image,
          rating: productData.rating || 0,
          reviewCount: 0,
          soldCount: productData.soldCount || 0,
          location: '',
          category: '',
        };

        if (marketplace === 'shopee' && productData.shopId && productData.itemId) {
          try {
            const apiUrl = 'https://shopee.co.id/api/v4/item/get?itemid=' + productData.itemId + '&shopid=' + productData.shopId;
            const res = await fetch(apiUrl, {
              credentials: 'include',
              headers: { 'Accept': 'application/json', 'X-Shopee-Language': 'id', 'X-API-SOURCE': 'pc' },
            });
            const data = await res.json();
            if (data.data) {
              const item = data.data;
              if (item.name) product.title = item.name;
              if (item.image) product.image = 'https://down-id.img.susercontent.com/file/' + item.image;
              else if (item.images && item.images.length > 0) product.image = 'https://down-id.img.susercontent.com/file/' + item.images[0];
              if (item.price_min || item.price) {
                const pv = item.price_min || item.price;
                product.price = Array.isArray(pv) ? pv[0] : pv;
              }
              if (item.price_min_before_discount || item.price_before_discount) {
                const op = item.price_min_before_discount || item.price_before_discount;
                const origPrice = Array.isArray(op) ? op[0] : op;
                if (origPrice > product.price) product.originalPrice = origPrice;
              }
              if (item.item_rating) {
                product.rating = item.item_rating.rating_star || 0;
                const rc = item.item_rating.rating_count;
                if (Array.isArray(rc)) product.reviewCount = rc.reduce((s, c) => s + (c || 0), 0);
                else if (typeof rc === 'number') product.reviewCount = rc;
              }
              if (item.historical_sold !== undefined && item.historical_sold !== null) {
                product.soldCount = item.historical_sold;
              } else if (item.sold !== undefined && item.sold !== null) {
                product.soldCount = item.sold;
              }
              if (item.shop_location) product.location = item.shop_location;
            }
          } catch (apiErr) {
            // API gagal, tetap pakai data dari DOM
          }
        }

        // Kirim product ke extension via postMessage
        window.postMessage({ type: 'JB_ADD_PRODUCT', product }, '*');

        // Tambahkan ke addedUrls
        addedUrls.add(productData.url);
        try {
          sessionStorage.setItem('jb-added-urls', JSON.stringify([...addedUrls]));
        } catch {}

        btn.classList.remove('jb-loading');
        btn.classList.add('jb-added');
        btn.textContent = '✓ Added';

        // Tampilkan toast
        showToast('✓ ' + (product.title || 'Produk').substring(0, 30) + '... ditambahkan!');
      } catch (err) {
        btn.classList.remove('jb-loading');
        btn.classList.add('jb-error');
        btn.textContent = '✗ Error';
        showToast('✗ Gagal: ' + (err.message || 'error'), true);
        setTimeout(() => {
          btn.classList.remove('jb-error');
          btn.textContent = '➕ JB';
        }, 2000);
      }
    });

    function showToast(msg, isError) {
      const existing = document.querySelector('.jb-toast');
      if (existing) existing.remove();
      const toast = document.createElement('div');
      toast.className = 'jb-toast';
      toast.textContent = msg;
      if (isError) toast.style.background = '#ef4444';
      document.body.appendChild(toast);
      setTimeout(() => toast.remove(), 2500);
    }

    card.appendChild(btn);
  }

  function processCards() {
    const selector = getCardSelector(marketplace);
    const cards = document.querySelectorAll(selector);
    cards.forEach(card => {
      if (card.querySelector('.jb-overlay-btn')) return; // sudah ada tombol
      if (card.getAttribute('data-jb-processed')) return;

      const productData = extractProductData(card);
      if (!productData.url || !productData.title) return;

      card.setAttribute('data-jb-processed', '1');
      createOverlayButton(card, productData);
    });
  }

  // Process existing cards
  processCards();

  // Observe DOM changes (Shopee lazy-load)
  const observer = new MutationObserver(() => {
    processCards();
  });
  observer.observe(document.body, { childList: true, subtree: true });

  // Listen for postMessage dari tombol → kirim ke background
  window.addEventListener('message', async (event) => {
    if (event.source !== window) return;
    if (event.data.type !== 'JB_ADD_PRODUCT') return;

    // Kirim ke extension via chrome.runtime
    try {
      chrome.runtime.sendMessage({ type: 'JB_ADD_PRODUCT', product: event.data.product });
    } catch {}
  });

  // Tandai mode aktif
  document.body.setAttribute('data-jb-overlay-mode', 'active');
}

// Function untuk hapus tombol overlay dari halaman
function removeOverlayButtons() {
  document.querySelectorAll('.jb-overlay-btn').forEach(b => b.remove());
  document.querySelectorAll('[data-jb-processed]').forEach(el => el.removeAttribute('data-jb-processed'));
  document.body.removeAttribute('data-jb-overlay-mode');
  // Hapus observer dengan reload attribute (tidak bisa disconnect observer dari luar, tapi tombol dihapus cukup)
}

// Listener untuk message dari content script (tombol overlay → add to collection)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'JB_ADD_PRODUCT' && msg.product) {
    addToCollection(msg.product).then(added => {
      sendResponse({ success: added });
    });
    return true; // keep channel open for async response
  }
});

// ═══════════════════════════════════════════════════════════════════
// v3.0: SCRAPE FROM PASTED LINK (Mode 2)
// ═══════════════════════════════════════════════════════════════════

function showLinkStatus(message, type) {
  const status = document.getElementById('linkStatus');
  status.textContent = message;
  status.className = 'status ' + type;
}

document.getElementById('scrapeLinkBtn').addEventListener('click', async () => {
  const textarea = document.getElementById('pasteLinkInput');
  const rawText = textarea.value.trim();
  if (!rawText) {
    showLinkStatus('❌ Paste URL produk dulu (1 per baris).', 'error');
    return;
  }

  const urls = rawText
    .split('\n')
    .map(u => u.trim())
    .filter(u => u.length > 10 && /^https?:\/\//i.test(u));

  if (urls.length === 0) {
    showLinkStatus('❌ Tidak ada URL valid. Format: https://...', 'error');
    return;
  }

  if (urls.length > 20) {
    showLinkStatus('⚠️ ' + urls.length + ' URL terdeteksi, hanya proses 20 pertama.', 'loading');
  }
  const urlsToProcess = urls.slice(0, 20);

  const btn = document.getElementById('scrapeLinkBtn');
  btn.disabled = true;
  btn.textContent = '⏳ Scraping...';

  let success = 0;
  let failed = 0;
  const errors = [];

  for (let i = 0; i < urlsToProcess.length; i++) {
    const url = urlsToProcess[i];
    btn.textContent = '⏳ ' + (i + 1) + '/' + urlsToProcess.length + ' scraping...';
    showLinkStatus('Scraping ' + (i + 1) + '/' + urlsToProcess.length + ': ' + url.slice(0, 60) + '...', 'loading');

    try {
      const marketplace = detectMarketplace(url);
      if (!marketplace) {
        failed++;
        errors.push(url.slice(0, 40) + ': marketplace tidak dikenali');
        continue;
      }

      let scraperFunc;
      if (marketplace === 'tiktok') scraperFunc = scrapeTikTokProduct;
      else if (marketplace === 'tokopedia') scraperFunc = scrapeTokopediaProduct;
      else if (marketplace === 'shopee') scraperFunc = scrapeShopeeProduct;
      else if (marketplace === 'blibli') scraperFunc = scrapeBlibliProduct;
      else if (marketplace === 'lazada') scraperFunc = scrapeLazadaProduct;
      else if (marketplace === 'bukalapak') scraperFunc = scrapeBukalapakProduct;
      else if (marketplace === 'zalora') scraperFunc = scrapeZaloraProduct;
      else if (marketplace === 'sociolla') scraperFunc = scrapeSociollaProduct;

      if (!scraperFunc) {
        failed++;
        errors.push(url.slice(0, 40) + ': scraper ' + marketplace + ' belum tersedia');
        continue;
      }

      const tab = await chrome.tabs.create({ url, active: false });

      await new Promise((resolve) => {
        let resolved = false;
        const timeout = setTimeout(() => {
          if (!resolved) { resolved = true; resolve(); }
        }, 15000);
        chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
          if (tabId === tab.id && info.status === 'complete' && !resolved) {
            resolved = true;
            clearTimeout(timeout);
            chrome.tabs.onUpdated.removeListener(listener);
            setTimeout(resolve, 2000);
          }
        });
      });

      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: scraperFunc,
      });

      try { await chrome.tabs.remove(tab.id); } catch {}

      const product = results[0]?.result;
      if (!product || !product.title) {
        failed++;
        errors.push(url.slice(0, 40) + ': gagal scrape (page belum loaded?)');
        continue;
      }

      product.marketplace = marketplace;
      product.url = url.split('?')[0];

      const added = await addToCollection(product);
      if (added) {
        success++;
      } else {
        failed++;
        errors.push(url.slice(0, 40) + ': sudah ada di koleksi (duplikat)');
      }
    } catch (err) {
      failed++;
      const errMsg = (err && err.message) ? err.message : 'error';
      errors.push(url.slice(0, 40) + ': ' + errMsg);
      try {
        const tabs = await chrome.tabs.query({ url: url.split('?')[0] + '*' });
        for (const t of tabs) {
          if (!t.active) await chrome.tabs.remove(t.id);
        }
      } catch {}
    }
  }

  btn.disabled = false;
  btn.textContent = '🔗 Scrape dari Link';

  if (failed === 0) {
    showLinkStatus('✅ ' + success + ' produk berhasil ditambahkan ke koleksi!', 'success');
    textarea.value = '';
  } else if (success > 0) {
    showLinkStatus('⚠️ ' + success + ' berhasil, ' + failed + ' gagal. Lihat console untuk detail (F12).', 'loading');
    console.log('[JB Scraper] Errors:', errors);
  } else {
    showLinkStatus('❌ Semua ' + failed + ' gagal. Pastikan URL valid & marketplace didukung.', 'error');
    console.log('[JB Scraper] Errors:', errors);
  }
});

// ═══════════════════════════════════════════════════════════════════
// v3.0: DOWNLOAD CSV (Output 1)
// ═══════════════════════════════════════════════════════════════════

function csvField(value) {
  if (value == null) return '';
  const s = String(value);
  if (/[",\n\r]/.test(s)) {
    return '"' + s.replace(/"/g, '""') + '"';
  }
  return s;
}

document.getElementById('downloadCsvBtn').addEventListener('click', async () => {
  const collection = await getCollection();
  if (collection.length === 0) {
    showUploadStatus('❌ Koleksi kosong.', 'error');
    return;
  }

  const headers = ['title', 'url', 'image', 'price', 'originalPrice', 'discountPercent',
                   'rating', 'reviewCount', 'soldCount', 'location', 'category',
                   'marketplace', 'affiliateUrl', 'notes'];
  const lines = [headers.join(',')];

  for (const p of collection) {
    const row = [
      csvField(p.title),
      csvField(p.url),
      csvField(p.image),
      csvField(p.price),
      csvField(p.originalPrice),
      csvField(p.discountPercent),
      csvField(p.rating),
      csvField(p.reviewCount),
      csvField(p.soldCount),
      csvField(p.location),
      csvField(p.category),
      csvField(p.marketplace),
      csvField(p.affiliateUrl),
      csvField(p.notes),
    ];
    lines.push(row.join(','));
  }

  const csvContent = lines.join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);

  const a = document.createElement('a');
  a.href = url;
  const dateStr = new Date().toISOString().slice(0, 10);
  a.download = 'jb-scrape-' + dateStr + '-' + collection.length + 'produk.csv';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);

  showUploadStatus('✅ CSV didownload: ' + collection.length + ' produk (' + a.download + ')', 'success');
});

// === UPLOAD ALL BUTTON ===

document.getElementById('uploadAllBtn').addEventListener('click', async () => {
  const collection = await getCollection();

  if (collection.length === 0) {
    showUploadStatus('❌ Koleksi kosong.', 'error');
    return;
  }

  if (!config.adminSecret) {
    showUploadStatus('❌ Isi Admin Secret dulu di Konfigurasi!', 'error');
    return;
  }

  showUploadStatus(`⏳ Uploading ${collection.length} produk...`, 'loading');

  // Cek marketplace override + category override
  const overrideMarketplace = document.getElementById('marketplaceOverride').value;
  const useOverride = overrideMarketplace !== 'auto';
  const overrideCategory = document.getElementById('categoryOverride').value;
  const useCategoryOverride = overrideCategory !== '';

  let success = 0;
  let failed = 0;
  const errors = [];

  // Upload satu per satu (lebih reliable daripada batch API)
  for (let i = 0; i < collection.length; i++) {
    const product = collection[i];

    // Apply marketplace override kalau dipilih
    const effectiveMarketplace = useOverride ? overrideMarketplace : product.marketplace;

    // Apply category override kalau dipilih
    const effectiveCategory = useCategoryOverride ? overrideCategory : (product.category || 'Lainnya');

    showUploadStatus(`⏳ Uploading ${i + 1}/${collection.length}: ${product.title.slice(0, 30)}... [${effectiveMarketplace}] [${effectiveCategory}]`, 'loading');

    try {
      const payload = {
        title: product.title,
        url: product.url,
        image: product.image,
        price: product.price,
        originalPrice: product.originalPrice || null,
        discountPercent: product.discountPercent || null,
        rating: product.rating || 4.5,
        reviewCount: product.reviewCount || 0,
        soldCount: product.soldCount || 0,
        location: product.location || null,
        category: effectiveCategory,
        marketplace: effectiveMarketplace,
        affiliateUrl: product.affiliateUrl || null,
        enabled: true,
        isViral: false,
      };

      const response = await fetch(`${config.apiBase}/api/shopee-products`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${config.adminSecret}`,
        },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        success++;
      } else if (response.status === 401) {
        failed++;
        errors.push('Admin Secret salah! Cek password di Config.');
        break; // Stop kalau auth gagal, tidak perlu lanjut
      } else {
        failed++;
        const data = await response.json().catch(() => ({}));
        errors.push(`${product.title.slice(0, 20)}: ${data.error || response.status}`);
      }
    } catch (err) {
      failed++;
      if (err.message.includes('Failed to fetch')) {
        errors.push('Network error — cek koneksi internet atau API URL');
        break; // Stop kalau network error, tidak perlu lanjut
      } else {
        errors.push(`${product.title.slice(0, 20)}: ${err.message}`);
      }
    }

    // Small delay antar upload (supaya tidak overload server)
    await new Promise(r => setTimeout(r, 300));
  }

  if (failed === 0) {
    showUploadStatus(`✅ Semua ${success} produk berhasil upload!`, 'success');
    await clearCollection();
  } else {
    showUploadStatus(`✅ ${success} berhasil, ❌ ${failed} gagal. ${errors.slice(0, 2).join('; ')}`, 'error');
  }
});

// Clear button
document.getElementById('clearAllBtn').addEventListener('click', async () => {
  if (confirm('Hapus semua produk dari koleksi?')) {
    await clearCollection();
    showStatus('✅ Koleksi dikosongkan.', 'success');
    setTimeout(() => hideStatus(), 2000);
  }
});

// === Helpers ===

function showStatus(message, type) {
  const status = document.getElementById('status');
  status.textContent = message;
  status.className = `status ${type}`;
}

function showUploadStatus(message, type) {
  const status = document.getElementById('uploadStatus');
  status.textContent = message;
  status.className = `status ${type}`;
}

function hideStatus() {
  document.getElementById('status').className = 'status';
}

function formatRupiah(n) {
  if (!n) return '-';
  return 'Rp ' + Number(n).toLocaleString('id-ID');
}

// === TIKTOK SHOP SCRAPER ===
function scrapeTikTokProduct() {
  let title = '';
  const titleEl = document.querySelector('h1[data-e2e="product-title"]')
    || document.querySelector('h1')
    || document.querySelector('[data-e2e="product-title"]')
    || document.querySelector('.product-title');
  if (titleEl) title = titleEl.textContent.trim();

  let price = 0;
  let originalPrice = null;
  let discountPercent = null;

  const priceEls = document.querySelectorAll('[data-e2e="product-price"], .price-current, span');
  for (const el of priceEls) {
    const text = el.textContent.trim();
    const match = text.match(/Rp\s*([\d.]+)/i);
    if (match) {
      const num = parseInt(match[1].replace(/\./g, ''), 10);
      if (num > 0) {
        if (price === 0) price = num;
        else if (num > price && !originalPrice) originalPrice = num;
      }
    }
  }

  const discountEl = document.querySelector('[data-e2e="product-discount"], .discount-percent');
  if (discountEl) {
    const match = discountEl.textContent.match(/(\d+)%/);
    if (match) discountPercent = parseInt(match[1], 10);
  }

  if (originalPrice && price && originalPrice > price) {
    discountPercent = Math.round((1 - price / originalPrice) * 100);
  }

  let image = '';
  const imgEl = document.querySelector('[data-e2e="product-image"] img')
    || document.querySelector('.product-image img')
    || document.querySelector('.slider-image img')
    || document.querySelector('main img');
  if (imgEl) image = imgEl.src || imgEl.dataset.src || '';

  let rating = 4.5;
  const ratingEl = document.querySelector('[data-e2e="product-rating"], .rating-value');
  if (ratingEl) {
    const match = ratingEl.textContent.match(/(\d+\.?\d*)/);
    if (match) rating = parseFloat(match[1]);
  }

  let reviewCount = 0;
  const reviewEl = document.querySelector('[data-e2e="product-review-count"], .review-count');
  if (reviewEl) {
    const match = reviewEl.textContent.match(/(\d+)/);
    if (match) reviewCount = parseInt(match[1], 10);
  }

  let soldCount = 0;
  const soldEl = document.querySelector('[data-e2e="product-sold"], .sold-count');
  if (soldEl) {
    const text = soldEl.textContent;
    if (text.includes('rb') || text.includes('k')) {
      const match = text.match(/(\d+\.?\d*)/);
      if (match) soldCount = Math.round(parseFloat(match[1]) * 1000);
    } else {
      const match = text.match(/(\d+)/);
      if (match) soldCount = parseInt(match[1], 10);
    }
  }

  let location = null;
  const locEl = document.querySelector('[data-e2e="product-location"], .seller-location');
  if (locEl) location = locEl.textContent.trim();

  const url = window.location.href;

  let category = 'Lainnya';
  const breadcrumbEl = document.querySelector('[data-e2e="breadcrumb-category"], .breadcrumb li:nth-child(2)');
  if (breadcrumbEl) {
    const cat = breadcrumbEl.textContent.trim();
    if (cat) category = cat;
  }

  return {
    title, price, originalPrice, discountPercent, image,
    rating, reviewCount, soldCount, location, url, category,
    affiliateUrl: null,
  };
}

// === TOKOPEDIA SCRAPER ===
function scrapeTokopediaProduct() {
  // === TITLE ===
  let title = '';
  const titleEl = document.querySelector('h1[data-testid="lblPDPDetailProductName"]')
    || document.querySelector('h1.css-1whll3a')
    || document.querySelector('[data-testid="pdpTileProductName"]')
    || document.querySelector('h1')
    || document.querySelector('[data-testid="pdpProductName"]')
    || document.querySelector('.product-title')
    || document.querySelector('[class*="ProductName"]');
  if (titleEl) title = titleEl.textContent.trim();

  // === PRICE ===
  let price = 0;
  let originalPrice = null;
  let discountPercent = null;

  // Coba multiple selectors untuk price
  const priceSelectors = [
    '[data-testid="lblPDPDetailProductPrice"]',
    '[data-testid="pdpTileProductPrice"]',
    '[data-testid="pdpNormalPrice"]',
    '[data-testid="pdpDiscountPrice"]',
    '.price',
    '[class*="price"][class*="current"]',
    '[class*="Price"][class*="Current"]',
    'span[class*="price"]',
    'div[class*="price"]',
  ];

  for (const sel of priceSelectors) {
    if (price > 0) break;
    const el = document.querySelector(sel);
    if (el) {
      const text = el.textContent.replace(/\s/g, '');
      const match = text.match(/Rp([\d.]+)/i);
      if (match) {
        price = parseInt(match[1].replace(/\./g, ''), 10);
      }
    }
  }

  // Fallback: cari semua elemen dengan "Rp" di teks
  if (price === 0) {
    const allEls = document.querySelectorAll('span, div, p');
    for (const el of allEls) {
      const text = el.textContent.trim();
      if (text.length < 30 && text.match(/^Rp\s*[\d.]+$/)) {
        const match = text.match(/Rp\s*([\d.]+)/i);
        if (match) {
          const num = parseInt(match[1].replace(/\./g, ''), 10);
          if (num > 1000) { // filter harga valid (>1000)
            price = num;
            break;
          }
        }
      }
    }
  }

  // Original price (harga coret)
  const originalSelectors = [
    '[data-testid="lblPDPDetailProductPriceStrikeout"]',
    '[data-testid="pdpTileProductPriceOriginal"]',
    '.price-strikeout',
    '[class*="price"][class*="strike"]',
    '[class*="Price"][class*="Strike"]',
  ];
  for (const sel of originalSelectors) {
    if (originalPrice) break;
    const el = document.querySelector(sel);
    if (el) {
      const text = el.textContent.replace(/\s/g, '');
      const match = text.match(/Rp([\d.]+)/i);
      if (match) originalPrice = parseInt(match[1].replace(/\./g, ''), 10);
    }
  }

  // Discount
  const discountEl = document.querySelector('[data-testid="lblPDPDetailProductDiscountPercentage"]')
    || document.querySelector('[data-testid="pdpTileProductDiscount"]');
  if (discountEl) {
    const match = discountEl.textContent.match(/(\d+)%/);
    if (match) discountPercent = parseInt(match[1], 10);
  }

  if (originalPrice && price && originalPrice > price) {
    discountPercent = Math.round((1 - price / originalPrice) * 100);
  }

  // === IMAGE ===
  let image = '';
  const imgSelectors = [
    '[data-testid="PDPMainImage"] img',
    '[data-testid="pdpTileProductImage"] img',
    '[data-testid="pdpMainImage"] img',
    '.product-image img',
    'main img[src*="tokopedia"]',
    'img[src*="images.tokopedia"]',
    'img[src*="ecs7"]',
    'picture img',
    'main img',
  ];
  for (const sel of imgSelectors) {
    if (image) break;
    const el = document.querySelector(sel);
    if (el) image = el.src || el.dataset.src || '';
  }

  // === RATING ===
  let rating = 4.5;
  const ratingEl = document.querySelector('[data-testid="lblPDPDetailProductRatingNumber"]')
    || document.querySelector('[data-testid="pdpTileProductRating"]');
  if (ratingEl) {
    const match = ratingEl.textContent.match(/(\d+\.?\d*)/);
    if (match) rating = parseFloat(match[1]);
  }

  // === REVIEW COUNT ===
  let reviewCount = 0;
  const reviewEl = document.querySelector('[data-testid="lblPDPDetailProductRatingCounter"]')
    || document.querySelector('[data-testid="pdpTileProductReviewCount"]');
  if (reviewEl) {
    const match = reviewEl.textContent.match(/(\d+)/);
    if (match) reviewCount = parseInt(match[1], 10);
  }

  // === SOLD COUNT ===
  let soldCount = 0;
  const soldEl = document.querySelector('[data-testid="lblPDPDetailProductSoldCount"]')
    || document.querySelector('[data-testid="pdpTileProductSold"]');
  if (soldEl) {
    const text = soldEl.textContent;
    if (text.includes('rb') || text.includes('k')) {
      const match = text.match(/(\d+\.?\d*)/);
      if (match) soldCount = Math.round(parseFloat(match[1]) * 1000);
    } else {
      const match = text.match(/(\d+)/);
      if (match) soldCount = parseInt(match[1], 10);
    }
  }

  // === LOCATION ===
  let location = null;
  const locSelectors = [
    '[data-testid="lblPDPDetailProductShopLocation"]',
    '[data-testid="pdpTileShopLocation"]',
    '[data-testid="pdpShopLocation"]',
    'a[href*="shop-location"]',
    '[class*="shop-location"]',
    '[class*="ShopLocation"]',
    '[class*="seller-location"]',
    '[class*="SellerLocation"]',
  ];
  for (const sel of locSelectors) {
    if (location) break;
    const els = document.querySelectorAll(sel);
    for (const el of els) {
      const text = el.textContent.trim();
      // Skip "Jakarta Barat" kalau muncul di banyak elemen (kemungkinan default/placeholder)
      // Hanya ambil kalau teks pendek (lokasi biasanya < 30 char) dan bukan "Jakarta Barat" default
      if (text && text.length > 2 && text.length < 50 && !text.includes('Lokasi') && !text.includes('Dikirim')) {
        location = text;
        break;
      }
    }
  }

  // === URL ===
  const url = window.location.href;

  // === CATEGORY (dengan fallback ke 'Lainnya') ===
  let category = 'Lainnya'; // default, supaya tidak kosong
  const breadcrumbEls = document.querySelectorAll('[data-testid="blPDPBreadCrumbItem"] a, .breadcrumb a, nav a');
  if (breadcrumbEls.length >= 2) {
    const cat = breadcrumbEls[breadcrumbEls.length - 1].textContent.trim();
    if (cat && cat.length > 1 && cat.length < 50) category = cat;
  }

  return {
    title, price, originalPrice, discountPercent, image,
    rating, reviewCount, soldCount, location,
    url, category,
    affiliateUrl: null,
  };
}

// === SHOPEE SCRAPER ===
function scrapeShopeeProduct() {
  let title = '';
  const titleEl = document.querySelector('div.qaNIZv')
    || document.querySelector('[data-sqe="name"]')
    || document.querySelector('h1')
    || document.querySelector('.qaNIZv');
  if (titleEl) title = titleEl.textContent.trim();

  let price = 0;
  let originalPrice = null;
  let discountPercent = null;

  const priceSelectors = [
    '.pqMkme', '.YE0TBc',
    '[data-sqe="price"]',
    'div[class*="price"][class*="current"]',
    'span[class*="price"]',
  ];
  for (const sel of priceSelectors) {
    if (price > 0) break;
    const el = document.querySelector(sel);
    if (el) {
      const text = el.textContent.replace(/\s/g, '');
      const match = text.match(/Rp([\d.]+)/i);
      if (match) price = parseInt(match[1].replace(/\./g, ''), 10);
    }
  }

  // Fallback: scan semua elemen
  if (price === 0) {
    const allEls = document.querySelectorAll('span, div');
    for (const el of allEls) {
      const text = el.textContent.trim();
      if (text.length < 30 && text.match(/^Rp\s*[\d.]+$/)) {
        const match = text.match(/Rp\s*([\d.]+)/i);
        if (match) {
          const num = parseInt(match[1].replace(/\./g, ''), 10);
          if (num > 1000) { price = num; break; }
        }
      }
    }
  }

  // Original price
  const origEl = document.querySelector('.JagmaB, [data-sqe="original-price"]');
  if (origEl) {
    const text = origEl.textContent.replace(/\s/g, '');
    const match = text.match(/Rp([\d.]+)/i);
    if (match) originalPrice = parseInt(match[1].replace(/\./g, ''), 10);
  }

  if (originalPrice && price && originalPrice > price) {
    discountPercent = Math.round((1 - price / originalPrice) * 100);
  }

  let image = '';
  const imgSelectors = [
    'img.QCAZEL',
    '[data-sqe="image"] img',
    '.product-image img',
    'main img[src*="shopee"]',
    'main img',
    'picture img',
  ];
  for (const sel of imgSelectors) {
    if (image) break;
    const el = document.querySelector(sel);
    if (el) image = el.src || el.dataset.src || '';
  }

  let rating = 4.5;
  const ratingEl = document.querySelector('.AcLMBa, [data-sqe="rating"]');
  if (ratingEl) {
    const match = ratingEl.textContent.match(/(\d+\.?\d*)/);
    if (match) rating = parseFloat(match[1]);
  }

  let soldCount = 0;
  const soldEl = document.querySelector('.Hmzvb5, [data-sqe="sold"]');
  if (soldEl) {
    const text = soldEl.textContent;
    if (text.includes('rb') || text.includes('k')) {
      const match = text.match(/(\d+\.?\d*)/);
      if (match) soldCount = Math.round(parseFloat(match[1]) * 1000);
    } else {
      const match = text.match(/(\d+)/);
      if (match) soldCount = parseInt(match[1], 10);
    }
  }

  let location = null;
  const locEl = document.querySelector('.X0Dc5j, [data-sqe="location"]');
  if (locEl) location = locEl.textContent.trim();

  let category = 'Lainnya';
  const breadcrumbEls = document.querySelectorAll('a[data-sqe="category"], .breadcrumb a');
  if (breadcrumbEls.length >= 1) {
    const cat = breadcrumbEls[breadcrumbEls.length - 1].textContent.trim();
    if (cat && cat.length > 1 && cat.length < 50) category = cat;
  }

  return {
    title, price, originalPrice, discountPercent, image,
    rating, reviewCount: 0, soldCount, location,
    url: window.location.href, category,
    affiliateUrl: null,
  };
}

// === BLIBLI SCRAPER ===
function scrapeBlibliProduct() {
  let title = '';
  const titleEl = document.querySelector('h1.product-name, h1, [class*="product-name"]');
  if (titleEl) title = titleEl.textContent.trim();

  let price = 0;
  let originalPrice = null;
  let discountPercent = null;

  const priceSelectors = [
    '.new-price-badge',
    '[class*="price"][class*="current"]',
    '[class*="Price"][class*="Current"]',
    'span[class*="price"]',
    'div[class*="price"]',
  ];
  for (const sel of priceSelectors) {
    if (price > 0) break;
    const el = document.querySelector(sel);
    if (el) {
      const text = el.textContent.replace(/\s/g, '');
      const match = text.match(/Rp([\d.]+)/i);
      if (match) price = parseInt(match[1].replace(/\./g, ''), 10);
    }
  }

  if (price === 0) {
    const allEls = document.querySelectorAll('span, div');
    for (const el of allEls) {
      const text = el.textContent.trim();
      if (text.length < 30 && text.match(/^Rp\s*[\d.]+$/)) {
        const match = text.match(/Rp\s*([\d.]+)/i);
        if (match) {
          const num = parseInt(match[1].replace(/\./g, ''), 10);
          if (num > 1000) { price = num; break; }
        }
      }
    }
  }

  const origEl = document.querySelector('[class*="price"][class*="strike"], [class*="Price"][class*="Strike"]');
  if (origEl) {
    const text = origEl.textContent.replace(/\s/g, '');
    const match = text.match(/Rp([\d.]+)/i);
    if (match) originalPrice = parseInt(match[1].replace(/\./g, ''), 10);
  }

  if (originalPrice && price && originalPrice > price) {
    discountPercent = Math.round((1 - price / originalPrice) * 100);
  }

  let image = '';
  const imgSelectors = [
    'img[class*="product-image"]',
    'main img[src*="blibli"]',
    'main img[src*="static-src"]',
    'main img',
    'picture img',
  ];
  for (const sel of imgSelectors) {
    if (image) break;
    const el = document.querySelector(sel);
    if (el) image = el.src || el.dataset.src || '';
  }

  let rating = 4.5;
  const ratingEl = document.querySelector('[class*="rating"], [class*="Rating"]');
  if (ratingEl) {
    const match = ratingEl.textContent.match(/(\d+\.?\d*)/);
    if (match) rating = parseFloat(match[1]);
  }

  let soldCount = 0;
  const soldEl = document.querySelector('[class*="sold"], [class*="Sold"]');
  if (soldEl) {
    const text = soldEl.textContent;
    const match = text.match(/(\d+)/);
    if (match) soldCount = parseInt(match[1], 10);
  }

  let location = null;
  const locEl = document.querySelector('[class*="location"], [class*="Location"]');
  if (locEl) location = locEl.textContent.trim();

  let category = 'Lainnya';
  const breadcrumbEls = document.querySelectorAll('a[class*="breadcrumb"], .breadcrumb a');
  if (breadcrumbEls.length >= 1) {
    const cat = breadcrumbEls[breadcrumbEls.length - 1].textContent.trim();
    if (cat && cat.length > 1 && cat.length < 50) category = cat;
  }

  return {
    title, price, originalPrice, discountPercent, image,
    rating, reviewCount: 0, soldCount, location,
    url: window.location.href, category,
    affiliateUrl: null,
  };
}

// === LAZADA SCRAPER ===
function scrapeLazadaProduct() {
  let title = '';
  const titleEl = document.querySelector('h1.pdp-product-title, h1, [class*="pdp-mod-product-title"]');
  if (titleEl) title = titleEl.textContent.trim();

  let price = 0;
  let originalPrice = null;
  let discountPercent = null;

  const priceSelectors = [
    '.pdp-price.pdp-price_type_normal',
    '[class*="pdp-price"]',
    'span[class*="price"]',
    'div[class*="price"]',
  ];
  for (const sel of priceSelectors) {
    if (price > 0) break;
    const el = document.querySelector(sel);
    if (el) {
      const text = el.textContent.replace(/\s/g, '');
      const match = text.match(/Rp([\d.]+)/i);
      if (match) price = parseInt(match[1].replace(/\./g, ''), 10);
    }
  }

  if (price === 0) {
    const allEls = document.querySelectorAll('span, div');
    for (const el of allEls) {
      const text = el.textContent.trim();
      if (text.length < 30 && text.match(/^Rp\s*[\d.]+$/)) {
        const match = text.match(/Rp\s*([\d.]+)/i);
        if (match) {
          const num = parseInt(match[1].replace(/\./g, ''), 10);
          if (num > 1000) { price = num; break; }
        }
      }
    }
  }

  const origEl = document.querySelector('[class*="pdp-price-type-original"], [class*="original"][class*="price"]');
  if (origEl) {
    const text = origEl.textContent.replace(/\s/g, '');
    const match = text.match(/Rp([\d.]+)/i);
    if (match) originalPrice = parseInt(match[1].replace(/\./g, ''), 10);
  }

  if (originalPrice && price && originalPrice > price) {
    discountPercent = Math.round((1 - price / originalPrice) * 100);
  }

  let image = '';
  const imgSelectors = [
    'img[class*="pdp-mod-common-image"]',
    'img[class*="gallery"]',
    'main img[src*="lazada"]',
    'main img',
    'picture img',
  ];
  for (const sel of imgSelectors) {
    if (image) break;
    const el = document.querySelector(sel);
    if (el) image = el.src || el.dataset.src || '';
  }

  let rating = 4.5;
  const ratingEl = document.querySelector('[class*="pdp-mod-review-rating"], [class*="score"]');
  if (ratingEl) {
    const match = ratingEl.textContent.match(/(\d+\.?\d*)/);
    if (match) rating = parseFloat(match[1]);
  }

  let soldCount = 0;
  const soldEl = document.querySelector('[class*="sold"], [class*="Sold"]');
  if (soldEl) {
    const text = soldEl.textContent;
    const match = text.match(/(\d+)/);
    if (match) soldCount = parseInt(match[1], 10);
  }

  let location = null;
  const locEl = document.querySelector('[class*="location"], [class*="Location"]');
  if (locEl) location = locEl.textContent.trim();

  let category = 'Lainnya';
  const breadcrumbEls = document.querySelectorAll('a[class*="breadcrumb"], .breadcrumb a, [class*="breadcrumb"] a');
  if (breadcrumbEls.length >= 1) {
    const cat = breadcrumbEls[breadcrumbEls.length - 1].textContent.trim();
    if (cat && cat.length > 1 && cat.length < 50) category = cat;
  }

  return {
    title, price, originalPrice, discountPercent, image,
    rating, reviewCount: 0, soldCount, location,
    url: window.location.href, category,
    affiliateUrl: null,
  };
}

// === BUKALAPAK SCRAPER ===
function scrapeBukalapakProduct() {
  let title = '';
  const titleEl = document.querySelector('h1[class*="product-name"], h1, [class*="product-name"]');
  if (titleEl) title = titleEl.textContent.trim();

  let price = 0;
  let originalPrice = null;
  let discountPercent = null;

  const priceSelectors = [
    '[class*="price"][class*="amount"]',
    '[class*="Price"][class*="Amount"]',
    'span[class*="price"]',
    'div[class*="price"]',
  ];
  for (const sel of priceSelectors) {
    if (price > 0) break;
    const el = document.querySelector(sel);
    if (el) {
      const text = el.textContent.replace(/\s/g, '');
      const match = text.match(/Rp([\d.]+)/i);
      if (match) price = parseInt(match[1].replace(/\./g, ''), 10);
    }
  }

  if (price === 0) {
    const allEls = document.querySelectorAll('span, div');
    for (const el of allEls) {
      const text = el.textContent.trim();
      if (text.length < 30 && text.match(/^Rp\s*[\d.]+$/)) {
        const match = text.match(/Rp\s*([\d.]+)/i);
        if (match) {
          const num = parseInt(match[1].replace(/\./g, ''), 10);
          if (num > 1000) { price = num; break; }
        }
      }
    }
  }

  const origEl = document.querySelector('[class*="price"][class*="strike"], [class*="original"][class*="price"]');
  if (origEl) {
    const text = origEl.textContent.replace(/\s/g, '');
    const match = text.match(/Rp([\d.]+)/i);
    if (match) originalPrice = parseInt(match[1].replace(/\./g, ''), 10);
  }

  if (originalPrice && price && originalPrice > price) {
    discountPercent = Math.round((1 - price / originalPrice) * 100);
  }

  let image = '';
  const imgSelectors = [
    'img[class*="product-image"]',
    'main img[src*="bukalapak"]',
    'main img',
    'picture img',
  ];
  for (const sel of imgSelectors) {
    if (image) break;
    const el = document.querySelector(sel);
    if (el) image = el.src || el.dataset.src || '';
  }

  let rating = 4.5;
  const ratingEl = document.querySelector('[class*="rating"], [class*="Rating"]');
  if (ratingEl) {
    const match = ratingEl.textContent.match(/(\d+\.?\d*)/);
    if (match) rating = parseFloat(match[1]);
  }

  let location = null;
  const locEl = document.querySelector('[class*="location"], [class*="Location"]');
  if (locEl) location = locEl.textContent.trim();

  let category = 'Lainnya';
  const breadcrumbEls = document.querySelectorAll('a[class*="breadcrumb"], .breadcrumb a');
  if (breadcrumbEls.length >= 1) {
    const cat = breadcrumbEls[breadcrumbEls.length - 1].textContent.trim();
    if (cat && cat.length > 1 && cat.length < 50) category = cat;
  }

  return {
    title, price, originalPrice, discountPercent, image,
    rating, reviewCount: 0, soldCount: 0, location,
    url: window.location.href, category,
    affiliateUrl: null,
  };
}

// === ZALORA SCRAPER ===
function scrapeZaloraProduct() {
  let title = '';
  const titleEl = document.querySelector('h1, h2[class*="product-name"], [class*="product-name"]');
  if (titleEl) title = titleEl.textContent.trim();

  let price = 0;
  let originalPrice = null;
  let discountPercent = null;

  const priceSelectors = [
    '[class*="price"][class*="current"]',
    '[class*="Price"][class*="Current"]',
    'span[class*="price"]',
    'div[class*="price"]',
  ];
  for (const sel of priceSelectors) {
    if (price > 0) break;
    const el = document.querySelector(sel);
    if (el) {
      const text = el.textContent.replace(/\s/g, '');
      const match = text.match(/Rp([\d.]+)/i);
      if (match) price = parseInt(match[1].replace(/\./g, ''), 10);
    }
  }

  if (price === 0) {
    const allEls = document.querySelectorAll('span, div');
    for (const el of allEls) {
      const text = el.textContent.trim();
      if (text.length < 30 && text.match(/^Rp\s*[\d.]+$/)) {
        const match = text.match(/Rp\s*([\d.]+)/i);
        if (match) {
          const num = parseInt(match[1].replace(/\./g, ''), 10);
          if (num > 1000) { price = num; break; }
        }
      }
    }
  }

  const origEl = document.querySelector('[class*="price"][class*="strike"], [class*="original"][class*="price"]');
  if (origEl) {
    const text = origEl.textContent.replace(/\s/g, '');
    const match = text.match(/Rp([\d.]+)/i);
    if (match) originalPrice = parseInt(match[1].replace(/\./g, ''), 10);
  }

  if (originalPrice && price && originalPrice > price) {
    discountPercent = Math.round((1 - price / originalPrice) * 100);
  }

  let image = '';
  const imgSelectors = [
    'img[class*="product-image"]',
    'main img[src*="zalora"]',
    'main img',
    'picture img',
  ];
  for (const sel of imgSelectors) {
    if (image) break;
    const el = document.querySelector(sel);
    if (el) image = el.src || el.dataset.src || '';
  }

  let rating = 4.5;
  const ratingEl = document.querySelector('[class*="rating"], [class*="Rating"]');
  if (ratingEl) {
    const match = ratingEl.textContent.match(/(\d+\.?\d*)/);
    if (match) rating = parseFloat(match[1]);
  }

  let category = 'Lainnya';
  const breadcrumbEls = document.querySelectorAll('a[class*="breadcrumb"], .breadcrumb a');
  if (breadcrumbEls.length >= 1) {
    const cat = breadcrumbEls[breadcrumbEls.length - 1].textContent.trim();
    if (cat && cat.length > 1 && cat.length < 50) category = cat;
  }

  return {
    title, price, originalPrice, discountPercent, image,
    rating, reviewCount: 0, soldCount: 0, location: null,
    url: window.location.href, category,
    affiliateUrl: null,
  };
}

// === SOCIOLLA SCRAPER ===
function scrapeSociollaProduct() {
  let title = '';
  const titleEl = document.querySelector('h1, h2[class*="product-name"], [class*="product-name"]');
  if (titleEl) title = titleEl.textContent.trim();

  let price = 0;
  let originalPrice = null;
  let discountPercent = null;

  const priceSelectors = [
    '[class*="price"][class*="current"]',
    '[class*="Price"][class*="Current"]',
    'span[class*="price"]',
    'div[class*="price"]',
  ];
  for (const sel of priceSelectors) {
    if (price > 0) break;
    const el = document.querySelector(sel);
    if (el) {
      const text = el.textContent.replace(/\s/g, '');
      const match = text.match(/Rp([\d.]+)/i);
      if (match) price = parseInt(match[1].replace(/\./g, ''), 10);
    }
  }

  if (price === 0) {
    const allEls = document.querySelectorAll('span, div');
    for (const el of allEls) {
      const text = el.textContent.trim();
      if (text.length < 30 && text.match(/^Rp\s*[\d.]+$/)) {
        const match = text.match(/Rp\s*([\d.]+)/i);
        if (match) {
          const num = parseInt(match[1].replace(/\./g, ''), 10);
          if (num > 1000) { price = num; break; }
        }
      }
    }
  }

  const origEl = document.querySelector('[class*="price"][class*="strike"], [class*="original"][class*="price"]');
  if (origEl) {
    const text = origEl.textContent.replace(/\s/g, '');
    const match = text.match(/Rp([\d.]+)/i);
    if (match) originalPrice = parseInt(match[1].replace(/\./g, ''), 10);
  }

  if (originalPrice && price && originalPrice > price) {
    discountPercent = Math.round((1 - price / originalPrice) * 100);
  }

  let image = '';
  const imgSelectors = [
    'img[class*="product-image"]',
    'main img[src*="sociolla"]',
    'main img',
    'picture img',
  ];
  for (const sel of imgSelectors) {
    if (image) break;
    const el = document.querySelector(sel);
    if (el) image = el.src || el.dataset.src || '';
  }

  let rating = 4.5;
  const ratingEl = document.querySelector('[class*="rating"], [class*="Rating"]');
  if (ratingEl) {
    const match = ratingEl.textContent.match(/(\d+\.?\d*)/);
    if (match) rating = parseFloat(match[1]);
  }

  let category = 'Lainnya';
  const breadcrumbEls = document.querySelectorAll('a[class*="breadcrumb"], .breadcrumb a');
  if (breadcrumbEls.length >= 1) {
    const cat = breadcrumbEls[breadcrumbEls.length - 1].textContent.trim();
    if (cat && cat.length > 1 && cat.length < 50) category = cat;
  }

  return {
    title, price, originalPrice, discountPercent, image,
    rating, reviewCount: 0, soldCount: 0, location: null,
    url: window.location.href, category,
    affiliateUrl: null,
  };
}
