# JB Scraper (All Marketplace) v3.1

Scrape produk dari **8 marketplace** (Shopee, Tokopedia, TikTok Shop, Blibli, Lazada, Bukalapak, Zalora, Sociolla) → koleksi → **Download CSV** atau **Upload langsung ke JB**.

## Yang Baru di v3.1 (NEW!)

### 🖱️ Mode 3: Klik di Halaman (aiprice-style) — PALING CEPAT
Aktifkan mode ini di halaman kategori/search Shopee, lalu **klik tombol "➕ JB"** yang muncul di tiap card produk. Produk di-scrape otomatis + masuk koleksi.

**Cara kerja:**
1. Buka halaman kategori/search Shopee (cth: cari "kaos kaki")
2. Klik icon JB Scraper → klik **"🖱️ Aktifkan Mode Klik"**
3. Popup tutup, tombol **"➕ JB"** (violet) muncul di tiap card produk
4. Klik tombol di produk mana → produk itu di-scrape (pakai Shopee API untuk data lengkap)
5. Tombol jadi **"✓ Added"** (hijau) + toast notifikasi
6. Klik produk lain, produk lain... sampai cukup
7. Buka lagi popup JB Scraper → klik **💾 Download CSV** atau **📤 Upload Semua**

**Kelebihan:**
- ✅ Tinggal klik, tidak perlu buka halaman detail 1-1
- ✅ Data lengkap (rating, review, sold, image, price) dari Shopee API
- ✅ Visual feedback (tombol hijau kalau sudah di-add)
- ✅ Auto-detect produk baru yang lazy-load (MutationObserver)

## 3 Mode Scraping

| Mode | Cara | Marketplace Support | Speed |
|------|------|---------------------|-------|
| **Mode 3** (v3.1 NEW) | Klik tombol overlay di card produk | Shopee (paling optimal) | ⚡ Cepat |
| **Mode 1** | Buka halaman detail → klik "Tambah" | Semua 8 marketplace | 🐢 Lambat (1-1) |
| **Mode 2** (v3.0) | Paste URL di textarea | Semua 8 marketplace | 🔄 Batch (20 URL) |

## 2 Opsi Output

Setelah koleksi terisi, pilih salah satu:
- **💾 Download CSV** → file CSV → upload via JB admin Bulk Upload (bisa auto-generate AT Custom Links dulu)
- **📤 Upload Semua ke JB** → langsung upload ke DB JB (perlu Admin Secret)

## Cara Install v3.1

1. Download & extract zip ini
2. Buka `edge://extensions` (atau `chrome://extensions`)
3. Aktifkan **Developer mode** (toggle kanan atas)
4. **Remove** versi lama (v2.2.0 atau v3.0) kalau ada
5. **Load unpacked** → pilih folder hasil extract
6. Icon JB muncul di toolbar

## Workflow yang Disarankan (RECOMMENDED)

### Workflow A: Mode 3 + Download CSV + Auto-generate AT Links
```
1. Buka Shopee, cari "kaos kaki" → sort Terlaris
2. Klik icon JB Scraper → klik "🖱️ Aktifkan Mode Klik"
3. Klik tombol "➕ JB" di 10-20 produk yang menarik
4. Klik icon JB Scraper lagi → klik "💾 Download CSV"
5. Login admin JB → Upload Massal → JB Upload
6. Upload file CSV → klik "🪄 Auto-generate AT Custom Links"
7. Klik "Upload Produk" → selesai!
```

### Workflow B: Mode 3 + Upload Langsung
```
1. Isi Admin Secret di Config section scraper
2. Buka Shopee, aktifkan Mode Klik
3. Klik produk yang mau di-scrape
4. Klik "📤 Upload Semua ke JB" → langsung masuk DB
```

## Troubleshooting

### Mode 3: Tombol "➕ JB" tidak muncul
- Pastikan di halaman **search/kategori** Shopee (URL: `shopee.co.id/search?...` atau `shopee.co.id/...cat...`)
- Scroll dulu supaya produk ke-load, lalu aktifkan mode
- Refresh halaman, lalu coba aktifkan lagi

### Mode 3: Klik tombol tapi "✗ Error"
- Shopee API mungkin rate-limit → tunggu 30 detik, coba lagi
- Produk mungkin sudah dihapus seller → coba produk lain

### Mode 3: Data tidak lengkap (rating/sold kosong)
- Shopee API kadang return data parsial → coba klik ulang
- Atau pakai Mode 1 (buka halaman detail) untuk data paling lengkap

### Download CSV: file tidak muncul
- Cek folder Downloads browser
- Nama file: `jb-scrape-YYYY-MM-DD-Nproduk.csv`

## Version History
- **v3.1.0** (current): Mode 3 (Klik di Halaman / aiprice-style) + Mode 2 + Download CSV
- v3.0.0: Mode 2 (Paste Link) + Download CSV
- v2.2.0: 8 marketplace support, direct upload only
- v1.0.0: Shopee only, copy CSV manual
