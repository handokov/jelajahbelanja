/**
 * JB Scraper v1.2 — Koleksi multi-produk + batch upload
 *
 * Fitur:
 * - Scrape produk → masuk ke koleksi (localStorage)
 * - Koleksi banyak produk (10, 20, 30, dst)
 * - Upload semua sekaligus (batch)
 * - Auto-detect marketplace (TikTok / Tokopedia)
 * - Skip duplikat (URL sama)
 * - Remove per produk
 */

// State
let config = {
  adminSecret: '',
  apiBase: 'https://jelajahbelanja.com'
};

// Load config
chrome.storage.local.get(['jbConfig', 'jbCollection'], (result) => {
  if (result.jbConfig) {
    config = { ...config, ...result.jbConfig };
    document.getElementById('adminSecret').value = config.adminSecret || '';
    document.getElementById('apiBase').value = config.apiBase || 'https://jelajahbelanja.com';
  }
  renderCollection();
});

// Save config
document.getElementById('saveConfig').addEventListener('click', () => {
  config.adminSecret = document.getElementById('adminSecret').value.trim();
  config.apiBase = document.getElementById('apiBase').value.trim().replace(/\/$/, '');
  chrome.storage.local.set({ jbConfig: config }, () => {
    showStatus('✅ Config disimpan!', 'success');
    setTimeout(() => hideStatus(), 2000);
  });
});

// Detect marketplace dari URL
function detectMarketplace(url) {
  const lower = url.toLowerCase();
  if (lower.includes('tiktok.com') || lower.includes('shop.tiktok.com')) return 'tiktok';
  if (lower.includes('tokopedia.com') || lower.includes('ta.tokopedia.com') ||
      lower.includes('tokopedia.link') || lower.includes('toko.link') ||
      lower.includes('shop-id.tokopedia.com')) return 'tokopedia';
  if (lower.includes('shopee.co.id') || lower.includes('shopee.com') || lower.includes('shope.ee')) return 'shopee';
  if (lower.includes('blibli.com')) return 'blibli';
  if (lower.includes('lazada.co.id')) return 'lazada';
  return null;
}

// === KOLEKSI MANAGEMENT ===

function getCollection() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['jbCollection'], (result) => {
      resolve(result.jbCollection || []);
    });
  });
}

function saveCollection(collection) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ jbCollection: collection }, resolve);
  });
}

async function addToCollection(product) {
  const collection = await getCollection();

  // Cek duplikat by URL
  const exists = collection.find(p => p.url === product.url);
  if (exists) {
    showStatus('⚠️ Produk sudah ada di koleksi (URL sama), di-skip.', 'error');
    return false;
  }

  collection.push(product);
  await saveCollection(collection);
  renderCollection();
  return true;
}

async function removeFromCollection(index) {
  const collection = await getCollection();
  collection.splice(index, 1);
  await saveCollection(collection);
  renderCollection();
}

async function clearCollection() {
  await saveCollection([]);
  renderCollection();
}

async function renderCollection() {
  const collection = await getCollection();
  const listEl = document.getElementById('productList');
  const countBadge = document.getElementById('countBadge');
  const uploadAllBtn = document.getElementById('uploadAllBtn');
  const clearAllBtn = document.getElementById('clearAllBtn');

  if (collection.length === 0) {
    listEl.innerHTML = '<div class="empty-list">Belum ada produk terkumpul.<br>Scrape beberapa produk dulu.</div>';
    countBadge.style.display = 'none';
    uploadAllBtn.disabled = true;
    clearAllBtn.disabled = true;
  } else {
    countBadge.style.display = 'inline-block';
    countBadge.textContent = collection.length;
    uploadAllBtn.disabled = false;
    clearAllBtn.disabled = false;

    listEl.innerHTML = collection.map((p, i) => `
      <div class="product-item">
        <img src="${p.image || ''}" alt="" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%2240%22 height=%2240%22><rect fill=%22%23f4f4f5%22 width=%2240%22 height=%2240%22/></svg>'">
        <div class="info">
          <div class="info-title">${escapeHtml(p.title.slice(0, 40))}${p.title.length > 40 ? '...' : ''}</div>
          <div class="info-price">${formatRupiah(p.price)}</div>
          <div class="info-mp">${p.marketplace}</div>
        </div>
        <button class="remove" data-index="${i}" title="Hapus">✕</button>
      </div>
    `).join('');

    // Add remove handlers
    listEl.querySelectorAll('.remove').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const idx = parseInt(e.target.dataset.index, 10);
        removeFromCollection(idx);
      });
    });
  }
}

function escapeHtml(s) {
  const div = document.createElement('div');
  div.textContent = s;
  return div.innerHTML;
}

// === SCRAPE BUTTON ===

document.getElementById('scrapeBtn').addEventListener('click', async () => {
  showStatus('⏳ Scrapping...', 'loading');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const marketplace = detectMarketplace(tab.url);

    if (!marketplace) {
      showStatus('❌ Buka halaman produk TikTok Shop atau Tokopedia dulu!', 'error');
      return;
    }

    let scraperFunc;
    if (marketplace === 'tiktok') scraperFunc = scrapeTikTokProduct;
    else if (marketplace === 'tokopedia') scraperFunc = scrapeTokopediaProduct;
    else {
      showStatus(`❌ Marketplace ${marketplace} belum didukung.`, 'error');
      return;
    }

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: scraperFunc,
    });

    const product = results[0]?.result;

    if (!product || !product.title) {
      showStatus('❌ Gagal scrape. Pastikan di halaman produk tunggal.', 'error');
      return;
    }

    product.marketplace = marketplace;

    const added = await addToCollection(product);
    if (added) {
      showStatus(`✅ Ditambahkan! (${await getCollectionLength()} produk di koleksi)`, 'success');
    }
  } catch (err) {
    showStatus('❌ Error: ' + err.message, 'error');
  }
});

async function getCollectionLength() {
  const c = await getCollection();
  return c.length;
}

// === UPLOAD ALL BUTTON ===

document.getElementById('uploadAllBtn').addEventListener('click', async () => {
  const collection = await getCollection();

  if (collection.length === 0) {
    showUploadStatus('❌ Koleksi kosong.', 'error');
    return;
  }

  if (!config.adminSecret) {
    showUploadStatus('❌ Isi Admin Secret dulu di Konfigurasi!', 'error');
    return;
  }

  showUploadStatus(`⏳ Uploading ${collection.length} produk...`, 'loading');

  let success = 0;
  let failed = 0;
  const errors = [];

  // Upload satu per satu (lebih reliable daripada batch API)
  for (let i = 0; i < collection.length; i++) {
    const product = collection[i];
    showUploadStatus(`⏳ Uploading ${i + 1}/${collection.length}: ${product.title.slice(0, 30)}...`, 'loading');

    try {
      const payload = {
        title: product.title,
        url: product.url,
        image: product.image,
        price: product.price,
        originalPrice: product.originalPrice || null,
        discountPercent: product.discountPercent || null,
        rating: product.rating || 4.5,
        reviewCount: product.reviewCount || 0,
        soldCount: product.soldCount || 0,
        location: product.location || null,
        category: product.category || 'Lainnya',
        marketplace: product.marketplace,
        affiliateUrl: product.affiliateUrl || null,
        enabled: true,
        isViral: false,
      };

      const response = await fetch(`${config.apiBase}/api/shopee-products`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${config.adminSecret}`,
        },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        success++;
      } else {
        failed++;
        const data = await response.json().catch(() => ({}));
        errors.push(`${product.title.slice(0, 20)}: ${data.error || response.status}`);
      }
    } catch (err) {
      failed++;
      errors.push(`${product.title.slice(0, 20)}: ${err.message}`);
    }

    // Small delay antar upload (supaya tidak overload server)
    await new Promise(r => setTimeout(r, 300));
  }

  if (failed === 0) {
    showUploadStatus(`✅ Semua ${success} produk berhasil upload!`, 'success');
    await clearCollection();
  } else {
    showUploadStatus(`✅ ${success} berhasil, ❌ ${failed} gagal. ${errors.slice(0, 2).join('; ')}`, 'error');
  }
});

// Clear button
document.getElementById('clearAllBtn').addEventListener('click', async () => {
  if (confirm('Hapus semua produk dari koleksi?')) {
    await clearCollection();
    showStatus('✅ Koleksi dikosongkan.', 'success');
    setTimeout(() => hideStatus(), 2000);
  }
});

// === Helpers ===

function showStatus(message, type) {
  const status = document.getElementById('status');
  status.textContent = message;
  status.className = `status ${type}`;
}

function showUploadStatus(message, type) {
  const status = document.getElementById('uploadStatus');
  status.textContent = message;
  status.className = `status ${type}`;
}

function hideStatus() {
  document.getElementById('status').className = 'status';
}

function formatRupiah(n) {
  if (!n) return '-';
  return 'Rp ' + Number(n).toLocaleString('id-ID');
}

// === TIKTOK SHOP SCRAPER ===
function scrapeTikTokProduct() {
  let title = '';
  const titleEl = document.querySelector('h1[data-e2e="product-title"]')
    || document.querySelector('h1')
    || document.querySelector('[data-e2e="product-title"]')
    || document.querySelector('.product-title');
  if (titleEl) title = titleEl.textContent.trim();

  let price = 0;
  let originalPrice = null;
  let discountPercent = null;

  const priceEls = document.querySelectorAll('[data-e2e="product-price"], .price-current, span');
  for (const el of priceEls) {
    const text = el.textContent.trim();
    const match = text.match(/Rp\s*([\d.]+)/i);
    if (match) {
      const num = parseInt(match[1].replace(/\./g, ''), 10);
      if (num > 0) {
        if (price === 0) price = num;
        else if (num > price && !originalPrice) originalPrice = num;
      }
    }
  }

  const discountEl = document.querySelector('[data-e2e="product-discount"], .discount-percent');
  if (discountEl) {
    const match = discountEl.textContent.match(/(\d+)%/);
    if (match) discountPercent = parseInt(match[1], 10);
  }

  if (originalPrice && price && originalPrice > price) {
    discountPercent = Math.round((1 - price / originalPrice) * 100);
  }

  let image = '';
  const imgEl = document.querySelector('[data-e2e="product-image"] img')
    || document.querySelector('.product-image img')
    || document.querySelector('.slider-image img')
    || document.querySelector('main img');
  if (imgEl) image = imgEl.src || imgEl.dataset.src || '';

  let rating = 4.5;
  const ratingEl = document.querySelector('[data-e2e="product-rating"], .rating-value');
  if (ratingEl) {
    const match = ratingEl.textContent.match(/(\d+\.?\d*)/);
    if (match) rating = parseFloat(match[1]);
  }

  let reviewCount = 0;
  const reviewEl = document.querySelector('[data-e2e="product-review-count"], .review-count');
  if (reviewEl) {
    const match = reviewEl.textContent.match(/(\d+)/);
    if (match) reviewCount = parseInt(match[1], 10);
  }

  let soldCount = 0;
  const soldEl = document.querySelector('[data-e2e="product-sold"], .sold-count');
  if (soldEl) {
    const text = soldEl.textContent;
    if (text.includes('rb') || text.includes('k')) {
      const match = text.match(/(\d+\.?\d*)/);
      if (match) soldCount = Math.round(parseFloat(match[1]) * 1000);
    } else {
      const match = text.match(/(\d+)/);
      if (match) soldCount = parseInt(match[1], 10);
    }
  }

  let location = null;
  const locEl = document.querySelector('[data-e2e="product-location"], .seller-location');
  if (locEl) location = locEl.textContent.trim();

  const url = window.location.href;

  let category = 'Lainnya';
  const breadcrumbEl = document.querySelector('[data-e2e="breadcrumb-category"], .breadcrumb li:nth-child(2)');
  if (breadcrumbEl) {
    const cat = breadcrumbEl.textContent.trim();
    if (cat) category = cat;
  }

  return {
    title, price, originalPrice, discountPercent, image,
    rating, reviewCount, soldCount, location, url, category,
    affiliateUrl: null,
  };
}

// === TOKOPEDIA SCRAPER ===
function scrapeTokopediaProduct() {
  let title = '';
  const titleEl = document.querySelector('h1[data-testid="lblPDPDetailProductName"]')
    || document.querySelector('h1.css-1whll3a')
    || document.querySelector('h1')
    || document.querySelector('[data-testid="pdpTileProductName"]')
    || document.querySelector('.product-title');
  if (titleEl) title = titleEl.textContent.trim();

  let price = 0;
  let originalPrice = null;
  let discountPercent = null;

  const priceEl = document.querySelector('[data-testid="lblPDPDetailProductPrice"]')
    || document.querySelector('[data-testid="pdpTileProductPrice"]')
    || document.querySelector('.price')
    || document.querySelector('[class*="price"][class*="current"]');
  if (priceEl) {
    const text = priceEl.textContent.replace(/\s/g, '');
    const match = text.match(/Rp([\d.]+)/i);
    if (match) price = parseInt(match[1].replace(/\./g, ''), 10);
  }

  const originalEl = document.querySelector('[data-testid="lblPDPDetailProductPriceStrikeout"]')
    || document.querySelector('[data-testid="pdpTileProductPriceOriginal"]')
    || document.querySelector('.price-strikeout')
    || document.querySelector('[class*="price"][class*="original"]');
  if (originalEl) {
    const text = originalEl.textContent.replace(/\s/g, '');
    const match = text.match(/Rp([\d.]+)/i);
    if (match) originalPrice = parseInt(match[1].replace(/\./g, ''), 10);
  }

  const discountEl = document.querySelector('[data-testid="lblPDPDetailProductDiscountPercentage"]')
    || document.querySelector('[data-testid="pdpTileProductDiscount"]')
    || document.querySelector('.discount');
  if (discountEl) {
    const match = discountEl.textContent.match(/(\d+)%/);
    if (match) discountPercent = parseInt(match[1], 10);
  }

  if (originalPrice && price && originalPrice > price) {
    discountPercent = Math.round((1 - price / originalPrice) * 100);
  }

  let image = '';
  const imgEl = document.querySelector('[data-testid="PDPMainImage"] img')
    || document.querySelector('[data-testid="pdpTileProductImage"] img')
    || document.querySelector('.product-image img')
    || document.querySelector('main img[src*="tokopedia"]')
    || document.querySelector('img[src*="images.tokopedia"]');
  if (imgEl) image = imgEl.src || imgEl.dataset.src || '';

  let rating = 4.5;
  const ratingEl = document.querySelector('[data-testid="lblPDPDetailProductRatingNumber"]')
    || document.querySelector('[data-testid="pdpTileProductRating"]')
    || document.querySelector('.rating-value');
  if (ratingEl) {
    const match = ratingEl.textContent.match(/(\d+\.?\d*)/);
    if (match) rating = parseFloat(match[1]);
  }

  let reviewCount = 0;
  const reviewEl = document.querySelector('[data-testid="lblPDPDetailProductRatingCounter"]')
    || document.querySelector('[data-testid="pdpTileProductReviewCount"]');
  if (reviewEl) {
    const match = reviewEl.textContent.match(/(\d+)/);
    if (match) reviewCount = parseInt(match[1], 10);
  }

  let soldCount = 0;
  const soldEl = document.querySelector('[data-testid="lblPDPDetailProductSoldCount"]')
    || document.querySelector('[data-testid="pdpTileProductSold"]');
  if (soldEl) {
    const text = soldEl.textContent;
    if (text.includes('rb') || text.includes('k')) {
      const match = text.match(/(\d+\.?\d*)/);
      if (match) soldCount = Math.round(parseFloat(match[1]) * 1000);
    } else {
      const match = text.match(/(\d+)/);
      if (match) soldCount = parseInt(match[1], 10);
    }
  }

  let location = null;
  const locEl = document.querySelector('[data-testid="lblPDPDetailProductShopLocation"]')
    || document.querySelector('[data-testid="pdpTileShopLocation"]');
  if (locEl) location = locEl.textContent.trim();

  const url = window.location.href;

  let category = 'Lainnya';
  const breadcrumbEls = document.querySelectorAll('[data-testid="blPDPBreadCrumbItem"] a, .breadcrumb a');
  if (breadcrumbEls.length >= 2) {
    const cat = breadcrumbEls[breadcrumbEls.length - 1].textContent.trim();
    if (cat) category = cat;
  }

  return {
    title, price, originalPrice, discountPercent, image,
    rating, reviewCount, soldCount, location,
    url, category,
    affiliateUrl: null,
  };
}
