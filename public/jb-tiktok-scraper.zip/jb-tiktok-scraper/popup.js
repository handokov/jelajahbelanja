/**
 * JB Scraper (TikTok + Tokopedia) — popup.js v1.1
 *
 * Support:
 * - TikTok Shop: shop.tiktok.com, www.tiktok.com
 * - Tokopedia (lama): www.tokopedia.com
 * - Tokopedia (baru): shop-id.tokopedia.com
 * - Tokopedia affiliate: ta.tokopedia.com, tokopedia.link, toko.link
 *
 * Cara kerja:
 * 1. User buka halaman produk
 * 2. Klik "Scrape" → detect marketplace dari URL → inject scraper sesuai
 * 3. Preview tampil
 * 4. Klik "Upload" → POST ke /api/shopee-products
 */

// State
let scrapedProduct = null;
let config = {
  adminSecret: '',
  apiBase: 'https://jelajahbelanja.com'
};

// Load config
chrome.storage.local.get(['jbConfig'], (result) => {
  if (result.jbConfig) {
    config = { ...config, ...result.jbConfig };
    document.getElementById('adminSecret').value = config.adminSecret || '';
    document.getElementById('apiBase').value = config.apiBase || 'https://jelajahbelanja.com';
  }
});

// Save config
document.getElementById('saveConfig').addEventListener('click', () => {
  config.adminSecret = document.getElementById('adminSecret').value.trim();
  config.apiBase = document.getElementById('apiBase').value.trim().replace(/\/$/, '');
  chrome.storage.local.set({ jbConfig: config }, () => {
    showStatus('✅ Config disimpan!', 'success');
    setTimeout(() => hideStatus(), 2000);
  });
});

// Detect marketplace dari URL
function detectMarketplace(url) {
  const lower = url.toLowerCase();
  if (lower.includes('tiktok.com') || lower.includes('shop.tiktok.com')) return 'tiktok';
  if (lower.includes('tokopedia.com') || lower.includes('ta.tokopedia.com') ||
      lower.includes('tokopedia.link') || lower.includes('toko.link') ||
      lower.includes('shop-id.tokopedia.com')) return 'tokopedia';
  if (lower.includes('shopee.co.id') || lower.includes('shopee.com') || lower.includes('shope.ee')) return 'shopee';
  if (lower.includes('blibli.com')) return 'blibli';
  if (lower.includes('lazada.co.id')) return 'lazada';
  return null;
}

// Scrape button
document.getElementById('scrapeBtn').addEventListener('click', async () => {
  showStatus('⏳ Scrapping...', 'loading');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const marketplace = detectMarketplace(tab.url);

    if (!marketplace) {
      showStatus('❌ Buka halaman produk TikTok Shop atau Tokopedia dulu!', 'error');
      return;
    }

    // Pilih scraper function sesuai marketplace
    let scraperFunc;
    if (marketplace === 'tiktok') scraperFunc = scrapeTikTokProduct;
    else if (marketplace === 'tokopedia') scraperFunc = scrapeTokopediaProduct;
    else {
      showStatus(`❌ Marketplace ${marketplace} belum didukung extension ini.`, 'error');
      return;
    }

    // Inject scrape function
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: scraperFunc,
    });

    const product = results[0]?.result;

    if (!product || !product.title) {
      showStatus('❌ Gagal scrape. Pastikan di halaman produk tunggal (bukan list/kategori).', 'error');
      return;
    }

    // Override marketplace dari detection (lebih akurat daripada dari page)
    product.marketplace = marketplace;
    scrapedProduct = product;
    showPreview(product);
    showStatus(`✅ Berhasil scrape produk ${marketplace}! Klik Upload.`, 'success');
    document.getElementById('uploadBtn').disabled = false;
  } catch (err) {
    showStatus('❌ Error: ' + err.message, 'error');
  }
});

// Upload button
document.getElementById('uploadBtn').addEventListener('click', async () => {
  if (!scrapedProduct) return;

  if (!config.adminSecret) {
    showStatus('❌ Isi Admin Secret dulu di Konfigurasi!', 'error');
    return;
  }

  showStatus('⏳ Uploading ke JelajahBelanja...', 'loading');

  try {
    const payload = {
      title: scrapedProduct.title,
      url: scrapedProduct.url,
      image: scrapedProduct.image,
      price: scrapedProduct.price,
      originalPrice: scrapedProduct.originalPrice || null,
      discountPercent: scrapedProduct.discountPercent || null,
      rating: scrapedProduct.rating || 4.5,
      reviewCount: scrapedProduct.reviewCount || 0,
      soldCount: scrapedProduct.soldCount || 0,
      location: scrapedProduct.location || null,
      category: scrapedProduct.category || 'Lainnya',
      marketplace: scrapedProduct.marketplace,
      affiliateUrl: scrapedProduct.affiliateUrl || null,
      enabled: true,
      isViral: false,
    };

    const response = await fetch(`${config.apiBase}/api/shopee-products`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${config.adminSecret}`,
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json();

    if (response.ok && (data.success || data.product)) {
      showStatus(`✅ Berhasil upload! ID: ${data.product?.id || 'created'}`, 'success');
      document.getElementById('uploadBtn').disabled = true;
    } else {
      showStatus(`❌ Gagal: ${data.error || 'Unknown error'}`, 'error');
    }
  } catch (err) {
    showStatus('❌ Network error: ' + err.message, 'error');
  }
});

// === Helpers ===

function showStatus(message, type) {
  const status = document.getElementById('status');
  status.textContent = message;
  status.className = `status ${type}`;
}

function hideStatus() {
  document.getElementById('status').className = 'status';
}

function showPreview(product) {
  document.getElementById('previewImg').src = product.image || '';
  document.getElementById('previewTitle').textContent = product.title.slice(0, 60) + (product.title.length > 60 ? '...' : '');
  document.getElementById('previewPrice').textContent = formatRupiah(product.price) + ` [${product.marketplace}]`;
  document.getElementById('productPreview').classList.add('visible');
}

function formatRupiah(n) {
  if (!n) return '-';
  return 'Rp ' + Number(n).toLocaleString('id-ID');
}

// === TIKTOK SHOP SCRAPER ===
function scrapeTikTokProduct() {
  let title = '';
  const titleEl = document.querySelector('h1[data-e2e="product-title"]')
    || document.querySelector('h1')
    || document.querySelector('[data-e2e="product-title"]')
    || document.querySelector('.product-title');
  if (titleEl) title = titleEl.textContent.trim();

  let price = 0;
  let originalPrice = null;
  let discountPercent = null;

  const priceEls = document.querySelectorAll('[data-e2e="product-price"], .price-current, span');
  for (const el of priceEls) {
    const text = el.textContent.trim();
    const match = text.match(/Rp\s*([\d.]+)/i);
    if (match) {
      const num = parseInt(match[1].replace(/\./g, ''), 10);
      if (num > 0) {
        if (price === 0) price = num;
        else if (num > price && !originalPrice) originalPrice = num;
      }
    }
  }

  const discountEl = document.querySelector('[data-e2e="product-discount"], .discount-percent');
  if (discountEl) {
    const match = discountEl.textContent.match(/(\d+)%/);
    if (match) discountPercent = parseInt(match[1], 10);
  }

  if (originalPrice && price && originalPrice > price) {
    discountPercent = Math.round((1 - price / originalPrice) * 100);
  }

  let image = '';
  const imgEl = document.querySelector('[data-e2e="product-image"] img')
    || document.querySelector('.product-image img')
    || document.querySelector('.slider-image img')
    || document.querySelector('main img');
  if (imgEl) image = imgEl.src || imgEl.dataset.src || '';

  let rating = 4.5;
  const ratingEl = document.querySelector('[data-e2e="product-rating"], .rating-value');
  if (ratingEl) {
    const match = ratingEl.textContent.match(/(\d+\.?\d*)/);
    if (match) rating = parseFloat(match[1]);
  }

  let reviewCount = 0;
  const reviewEl = document.querySelector('[data-e2e="product-review-count"], .review-count');
  if (reviewEl) {
    const match = reviewEl.textContent.match(/(\d+)/);
    if (match) reviewCount = parseInt(match[1], 10);
  }

  let soldCount = 0;
  const soldEl = document.querySelector('[data-e2e="product-sold"], .sold-count');
  if (soldEl) {
    const text = soldEl.textContent;
    if (text.includes('rb') || text.includes('k')) {
      const match = text.match(/(\d+\.?\d*)/);
      if (match) soldCount = Math.round(parseFloat(match[1]) * 1000);
    } else {
      const match = text.match(/(\d+)/);
      if (match) soldCount = parseInt(match[1], 10);
    }
  }

  let location = null;
  const locEl = document.querySelector('[data-e2e="product-location"], .seller-location');
  if (locEl) location = locEl.textContent.trim();

  const url = window.location.href;

  let category = 'Lainnya';
  const breadcrumbEl = document.querySelector('[data-e2e="breadcrumb-category"], .breadcrumb li:nth-child(2)');
  if (breadcrumbEl) {
    const cat = breadcrumbEl.textContent.trim();
    if (cat) category = cat;
  }

  return {
    title, price, originalPrice, discountPercent, image,
    rating, reviewCount, soldCount, location, url, category,
    affiliateUrl: null,
  };
}

// === TOKOPEDIA SCRAPER (support format lama + shop-id.tokopedia.com baru) ===
function scrapeTokopediaProduct() {
  // === TITLE ===
  let title = '';
  const titleEl = document.querySelector('h1[data-testid="lblPDPDetailProductName"]')
    || document.querySelector('h1.css-1whll3a')
    || document.querySelector('h1')
    || document.querySelector('[data-testid="pdpTileProductName"]')
    || document.querySelector('.product-title');
  if (titleEl) title = titleEl.textContent.trim();

  // === PRICE ===
  let price = 0;
  let originalPrice = null;
  let discountPercent = null;

  // Harga utama
  const priceEl = document.querySelector('[data-testid="lblPDPDetailProductPrice"]')
    || document.querySelector('[data-testid="pdpTileProductPrice"]')
    || document.querySelector('.price')
    || document.querySelector('[class*="price"][class*="current"]');
  if (priceEl) {
    const text = priceEl.textContent.replace(/\s/g, '');
    const match = text.match(/Rp([\d.]+)/i);
    if (match) price = parseInt(match[1].replace(/\./g, ''), 10);
  }

  // Harga coret (original price)
  const originalEl = document.querySelector('[data-testid="lblPDPDetailProductPriceStrikeout"]')
    || document.querySelector('[data-testid="pdpTileProductPriceOriginal"]')
    || document.querySelector('.price-strikeout')
    || document.querySelector('[class*="price"][class*="original"]');
  if (originalEl) {
    const text = originalEl.textContent.replace(/\s/g, '');
    const match = text.match(/Rp([\d.]+)/i);
    if (match) originalPrice = parseInt(match[1].replace(/\./g, ''), 10);
  }

  // Discount persen
  const discountEl = document.querySelector('[data-testid="lblPDPDetailProductDiscountPercentage"]')
    || document.querySelector('[data-testid="pdpTileProductDiscount"]')
    || document.querySelector('.discount');
  if (discountEl) {
    const match = discountEl.textContent.match(/(\d+)%/);
    if (match) discountPercent = parseInt(match[1], 10);
  }

  if (originalPrice && price && originalPrice > price) {
    discountPercent = Math.round((1 - price / originalPrice) * 100);
  }

  // === IMAGE ===
  let image = '';
  const imgEl = document.querySelector('[data-testid="PDPMainImage"] img')
    || document.querySelector('[data-testid="pdpTileProductImage"] img')
    || document.querySelector('.product-image img')
    || document.querySelector('main img[src*="tokopedia"]')
    || document.querySelector('img[src*="images.tokopedia"]');
  if (imgEl) image = imgEl.src || imgEl.dataset.src || '';

  // === RATING ===
  let rating = 4.5;
  const ratingEl = document.querySelector('[data-testid="lblPDPDetailProductRatingNumber"]')
    || document.querySelector('[data-testid="pdpTileProductRating"]')
    || document.querySelector('.rating-value');
  if (ratingEl) {
    const match = ratingEl.textContent.match(/(\d+\.?\d*)/);
    if (match) rating = parseFloat(match[1]);
  }

  // === REVIEW COUNT ===
  let reviewCount = 0;
  const reviewEl = document.querySelector('[data-testid="lblPDPDetailProductRatingCounter"]')
    || document.querySelector('[data-testid="pdpTileProductReviewCount"]');
  if (reviewEl) {
    const text = reviewEl.textContent;
    const match = text.match(/(\d+)/);
    if (match) reviewCount = parseInt(match[1], 10);
  }

  // === SOLD COUNT ===
  let soldCount = 0;
  const soldEl = document.querySelector('[data-testid="lblPDPDetailProductSoldCount"]')
    || document.querySelector('[data-testid="pdpTileProductSold"]');
  if (soldEl) {
    const text = soldEl.textContent;
    if (text.includes('rb') || text.includes('k')) {
      const match = text.match(/(\d+\.?\d*)/);
      if (match) soldCount = Math.round(parseFloat(match[1]) * 1000);
    } else {
      const match = text.match(/(\d+)/);
      if (match) soldCount = parseInt(match[1], 10);
    }
  }

  // === LOCATION ===
  let location = null;
  const locEl = document.querySelector('[data-testid="lblPDPDetailProductShopLocation"]')
    || document.querySelector('[data-testid="pdpTileShopLocation"]');
  if (locEl) location = locEl.textContent.trim();

  // === URL ===
  const url = window.location.href;

  // === CATEGORY ===
  let category = 'Lainnya';
  // Coba ambil dari breadcrumb
  const breadcrumbEls = document.querySelectorAll('[data-testid="blPDPBreadCrumbItem"] a, .breadcrumb a');
  if (breadcrumbEls.length >= 2) {
    const cat = breadcrumbEls[breadcrumbEls.length - 1].textContent.trim();
    if (cat) category = cat;
  } else {
    // Fallback: ambil dari URL pattern
    // Format: shop-id.tokopedia.com/products/xxx atau www.tokopedia.com/shopname/productname
    const urlMatch = url.match(/tokopedia\.com\/([^\/]+)\/([^\/\?#]+)/);
    if (urlMatch && urlMatch[2] && urlMatch[2] !== 'products') {
      // Pakai bagian shop name sebagai hint kategori (rough)
      // Lebih baik pakai "Lainnya" kalau tidak yakin
    }
  }

  // Auto-detect: kalau URL shop-id.tokopedia.com, normalize URL ke www.tokopedia.com
  let normalizedUrl = url;
  if (url.includes('shop-id.tokopedia.com')) {
    // shop-id.tokopedia.com/products/xxx → tetap pakai URL asli (TikTok-style shortlink)
    // Tapi simpan untuk referensi
  }

  return {
    title, price, originalPrice, discountPercent, image,
    rating, reviewCount, soldCount, location,
    url: normalizedUrl, category,
    affiliateUrl: null, // User isi manual (AT belum support Tokopedia quicklink)
  };
}
